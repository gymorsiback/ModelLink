import numpy as np
import math
from torch_geometric.data import Data
import torch
import networkx as nx
import matplotlib.pyplot as plt
import pandas as pd
from utils import *
import os
script_dir = os.path.dirname(os.path.abspath(__file__))
os.chdir(script_dir)


# 读取CSV文件
df_server = pd.read_csv('data/server_data.csv')
df_1 = pd.read_csv('data/model_t2t.csv')
df_2 = pd.read_csv('data/model_t2i.csv')
df_3 = pd.read_csv('data/model_i2v.csv')
df_4 = pd.read_csv('data/model_t2v.csv')
df_5 = pd.read_csv('data/model_a2t.csv')
df_6 = pd.read_csv('data/model_t2a.csv')
df_edge = pd.read_csv('data/edge.csv')
# 假设CSV文件中的列名分别是'Longitude'和'Latitude'
locations = df_server[['Longitude', 'Latitude']].values.tolist()
# print(locations)
# 显卡型号跑分
server_performence = df_server['ServerPerformance'].tolist()
# print(server_performence)
node_num = df_server.shape[0]
train_mask = np.ones(node_num)
Y = np.zeros(node_num)
node_class = {0: 0}
# 创一个字典，记录model_id对应的server_id
model_server_dict = pd.Series(df_server['ServerID'].values, index=df_server['ModelID']).to_dict()

# 文生文模型评分
model_1 = df_1[['ModelID', 'ModelPerformance']].values.tolist()
model_1_efficiency = df_1[['ModelEfficiency']].values.tolist()
for server_id in df_1['ModelID'].values.tolist():
    Y[server_id-1] = 1
    node_class[server_id] = 1
# 文生图模型评分
model_2 = df_2[['ModelID', 'ModelPerformance']].values.tolist()
model_2_efficiency = df_2[['ModelEfficiency']].values.tolist()
for server_id in df_2['ModelID'].values.tolist():
    Y[server_id-1] = 2
    node_class[server_id] = 2
# 图生视频，评分随便写的，需要改
model_3 = df_3[['ModelID', 'ModelPerformance']].values.tolist()
model_3_efficiency = df_3[['ModelEfficiency']].values.tolist()
for server_id in df_3['ModelID'].values.tolist():
    Y[server_id-1] = 3
    node_class[server_id] = 3
# 文生视频，评分随便写的，需要改
model_4 = df_4[['ModelID', 'ModelPerformance']].values.tolist()
model_4_efficiency = df_4[['ModelEfficiency']].values.tolist()
for server_id in df_4['ModelID'].values.tolist():
    Y[server_id-1] = 4
    node_class[server_id] = 4
# 音生文，评分随便写的，需要改
model_5 = df_5[['ModelID', 'ModelPerformance']].values.tolist()
model_5_efficiency = df_5[['ModelEfficiency']].values.tolist()
for server_id in df_5['ModelID'].values.tolist():
    Y[server_id-1] = 5
    node_class[server_id] = 5
# 文生音，评分随便写的，需要改
model_6 = df_6[['ModelID', 'ModelPerformance']].values.tolist()
model_6_efficiency = df_6[['ModelEfficiency']].values.tolist()
for server_id in df_6['ModelID'].values.tolist():
    Y[server_id-1] = 6
    node_class[server_id] = 6
Y = Y.tolist()

# print(Y)
# print(node_class)
# 模型效率未知，全部为1

model_efficiency = np.vstack((model_1_efficiency, model_2_efficiency, model_3_efficiency, model_4_efficiency, model_5_efficiency, model_6_efficiency))
# print("model_efficiency=", model_efficiency)
# 最大最小归一化函数
def minmax_normalize(data):
    normalized = [[0, 0] for _ in range(len(data))]

    # 如果只有一行,不做归一化
    if len(data) == 1:
        normalized[0][0] = data[0][0]
        normalized[0][1] = 1
        return normalized

    col = [row[1] for row in data]
    min_val = min(col)
    max_val = max(col)

    if min_val == max_val:
        for i, row in enumerate(data):
            normalized[i][0] = row[0]
            normalized[i][1] = 1
    else:
        for i, row in enumerate(data):
            normalized[i][0] = row[0]
            normalized[i][1] = (row[1] - min_val) / (max_val - min_val) + 1

    return normalized

# 6个评分归一化的n * 2的矩阵
M_1 = minmax_normalize(model_1)
M_2 = minmax_normalize(model_2)
M_3 = minmax_normalize(model_3)
M_4 = minmax_normalize(model_4)
M_5 = minmax_normalize(model_5)
M_6 = minmax_normalize(model_6)
# 垂直拼起来，就是所有模型的序号和评分，该评分就是节点的第四个维度
model_performence = np.vstack((M_1, M_2, M_3, M_4, M_5, M_6))
# print("data_model_performence =",model_performence)
# print("model_1 =",model_1)
# print("M_1 =",M_1)
# print("model_performence=", model_performence)

# 拼成一个16 * 6的矩阵，作为节点矩阵
node_matrix = np.hstack((np.array(locations),
                         np.array(server_performence).reshape(-1,1),
                         model_performence,
                         np.array(model_efficiency).reshape(-1,1) ))
# print("node_matrix=", node_matrix)
# 新矩阵,交换列顺序,这个Node_matrix的后五列就是要的节点矩阵，第一列是序号，0-16
Node_matrix = np.zeros_like(node_matrix)
Node_matrix[:,0] = node_matrix[:,3]
Node_matrix[:,1] = node_matrix[:,0]
Node_matrix[:,2] = node_matrix[:,1]
Node_matrix[:,3] = node_matrix[:,2]
Node_matrix[:,4] = node_matrix[:,4]
Node_matrix[:,5] = node_matrix[:,5]
# print("Node_matrix=", Node_matrix)
# print(type(Node_matrix[0][2]))
# 节点特征向量建模完成

# 接下来建模邻接矩阵



# 邻接矩阵，GCN表示形式
edge_row_1 = df_edge.iloc[0].values.tolist()
edge_row_2 = df_edge.iloc[1].values.tolist()
# 将 edge_row_1 的所有元素转换为整数
edge_row_1 = [int(x) if isinstance(x, (int, float, str)) else x for x in edge_row_1]

# 将 edge_row_2 的所有元素转换为整数
edge_row_2 = [int(x) if isinstance(x, (int, float, str)) else x for x in edge_row_2]
# 边特征向量（暂定1维）
edge = np.vstack((edge_row_1, edge_row_2))
# print("edge=", edge)
edge_features = []
for i in range(len(edge[0])):
    n1 = edge[0][i] - 1
    n2 = edge[1][i] - 1
    lon1, lat1 = locations[n1][0], locations[n1][1]
    lon2, lat2 = locations[n2][0], locations[n2][1]

    distance = haversine(lon1, lat1, lon2, lat2)
    edge_features.append([distance])

edge_features = np.array(edge_features)

'''
G = nx.Graph()

# 将节点和边添加到图中
for i in range(len(edge[0])):
    G.add_edge(edge[0][i] - 1, edge[1][i] - 1)  # 减1以调整节点标识符

# 使用 Spring Layout 进行节点布局
pos = nx.spring_layout(G, seed=42)

# 绘制图形
plt.figure(figsize=(10, 8))
nx.draw_networkx(G, pos, with_labels=True, node_size=400, node_color='skyblue', font_size=8, font_color='black', font_weight='bold')
plt.title("Graph Visualization")
plt.show()
'''

Node_matrix = Node_matrix.astype(np.float64)
edge = edge.astype(np.int64)
edge_features = edge_features.astype(np.float64)
# 创建data
data = Data(x=torch.tensor(Node_matrix, dtype=torch.float),
            edge_index=torch.tensor(edge, dtype=torch.float),
            edge_attr=torch.tensor(edge_features, dtype=torch.float))
print("dataforGNN=", data)

