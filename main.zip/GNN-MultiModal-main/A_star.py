# 贪心算法实现，计时
from dataPreprocess import *
from collections import defaultdict
from GNN.GNN_init import node_embeddings
import numpy as np
import heapq
import time
from userRequest import *

# # 输出最小的经度和纬度，为假设的用户服务器位置

# min_1 = min(longitude)
# min_2 = max(latitude)


def A_star_final(lo, la, route, w1, w2, node_embeddings,edge=edge,edge_features=edge_features,locations=locations,model_performence=model_performence):
    import copy
    edge_copy = copy.deepcopy(edge)
    edge_features_copy = copy.deepcopy(edge_features)
    locations_copy = copy.deepcopy(locations)
    model_performence_copy = copy.deepcopy(model_performence)
    # 将列表解析成经度和纬度的两个列表
    longitude, latitude = zip(*locations_copy)
    route.insert(0, len(locations_copy)+1)
    route.append(len(locations_copy)+1)
    # 计算[min_1,min_2]到locations中所有坐标的距离
    distance = [haversine(lo, la, lon, lat) for lon, lat in zip(longitude, latitude)]
    edge_copy = edge_copy.tolist()
    edge_features_copy = edge_features_copy.tolist()
    
    # 将[min_1,min_2]到所有其他节点的边添加到 edge 中
    for i in range(len(locations_copy)):
        # 可去
        edge_copy[0].append(len(locations_copy) + 1)  # 17 号点的索引
        edge_copy[1].append(i + 1)
        # 可回
        edge_copy[0].append(i + 1)
        edge_copy[1].append(len(locations_copy) + 1)
    # 复制每个元素并放在原元素的后面
    distance_copy = np.repeat(distance, 2)

    # 将相应的距离添加到 edge_features 中
    edge_features_flat = [item for sublist in edge_features_copy for item in sublist]
    edge_features_flat.extend(
        distance_copy)  # 可以把每条边target点上耽误的时间都算进这条边的距离中，具体计算为这条边对应target点的(c1/server_performence + c2/model_efficiency)加到对应的edge_features_flat中
    node_efficiency = []
    # 权重，根据测试自己调整
    c1 = 1
    c2 = 1
    c3 = 1
    # model_performence
    for i in range(len(model_efficiency)):
        node_efficiency.append(c1 / (server_performence[i] * model_efficiency[i]))  # (c1 / server_performence[i]) + (c2 / model_efficiency[i])
    node_efficiency = [float(value) for value in node_efficiency]
    second_elements = [sub_array[1] for sub_array in model_performence_copy]  # second_elements是model_performence中元素的第二个元素
    for i in range(len(edge_copy[1])):
        if edge_copy[1][i] == len(locations_copy) + 1:
            edge_features_flat[i] += 0
        else:
            edge_features_flat[i] = w1 * (node_efficiency[edge_copy[1][i] - 1] + c2 * edge_features_flat[i]) + w2 * (c3 / second_elements[edge_copy[1][i] - 1])
    # print("edge =", edge)
    # print("edge_features_flat =", edge_features_flat)
    Y_copy = copy.deepcopy(Y)
    Y_copy.append(len(locations_copy) + 1)
    # print(Y_copy)
    # Initialize the route_pro array
    route_pro = []
    # Fill route_pro based on the condition
    for r in route:
        indices = [i + 1 for i, y in enumerate(Y_copy) if y == r]
        route_pro.append(indices)
    # print(route_pro)

    locations_copy.append([lo, la])
    # graph和costs
    graph, costs = create_graph_and_costs(edge_copy, edge_features_flat)

    def a_star(graph, costs, start_set, end_set):
        open_set = [(0, start, 0) for start in start_set]  # (f_score, node, g_score)
        heapq.heapify(open_set)
        came_from = {}
        g_score = defaultdict(lambda: float('inf'))
        for start in start_set:
            g_score[start] = 0

        while open_set:
            _, current, current_g_score = heapq.heappop(open_set)

            if current in end_set:
                path = []
                total_cost = current_g_score
                while current in came_from:
                    path.append(current)
                    current = came_from[current]
                path.append(current)
                path.reverse()
                return path, total_cost

            for neighbor in graph[current]:
                tentative_g_score = current_g_score + costs.get((current, neighbor), float('inf'))
                if tentative_g_score < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g_score
                    f_score = tentative_g_score + heuristic(neighbor, end_set, costs)
                    heapq.heappush(open_set, (f_score, neighbor, tentative_g_score))

        return None, float('inf')
    # def heuristic(node, goal):
    #     # 简化版的启发式函数，这里假设为0，因为我们的路径受到route_pro的限制
    #     # return haversine(locations_copy[node - 1][0], locations_copy[node - 1][1], locations_copy[goal - 1][0],locations_copy[goal - 1][1])
    #     # return torch.norm(node_embeddings[node - 1] - node_embeddings[goal - 1], p=2).item()
    #     return 0
    def heuristic(current, next_set, costs):
        # return min(costs.get((current, next), float('inf')) for next in next_set)
        min_cost = float('inf')
        min_next_node = current
        for next_node in next_set:
            cost = costs.get((current, next_node), float('inf'))
            if cost < min_cost:
                min_cost = cost
                min_next_node = next_node
        return min_cost + torch.norm(node_embeddings[min_next_node - 1] - node_embeddings[-1], p=2).item()

    def find_optimal_path(graph, costs, route_pro):
        total_path = []
        total_cost = 0

        for i in range(len(route_pro) - 1):
            path, cost = a_star(graph, costs, route_pro[i], route_pro[i + 1])
            if path is None:
                return None, float('inf')
            total_path.extend(path[:-1])  # Avoid duplicating nodes between segments
            total_cost += cost

        total_path.append(route_pro[-1][0])  # Add the final node
        return total_path, total_cost

    optimal_path, optimal_cost = find_optimal_path(graph, costs, route_pro)
    print(f"Optimal Path: {optimal_path}, Cost: {optimal_cost}")
    route.pop(0)
    route.pop()
    return optimal_path
    # # 使用默认字典收集每个类别的坐标
    # category_coordinates = defaultdict(list)
    #
    # for lon, lat, category in zip(longitude, latitude, Y):
    #     category_coordinates[category].append((lon, lat))
    #
    # # 绘制散点图
    # plt.figure(figsize=(10, 8))
    #
    # # 遍历类别字典，绘制相同类别的坐标使用相同颜色
    # for category, coordinates in category_coordinates.items():
    #     color = plt.cm.jet(category / max(Y))  # 使用viridis颜色映射
    #     plt.scatter(*zip(*coordinates), color=color, s=50, label=f'Category {category}')
    #
    # # 添加标签和标题
    # plt.xlabel('Longitude')
    # plt.ylabel('Latitude')
    # plt.title('Scatter Plot of Coordinates')
    #
    # # 绘制用户点
    # plt.scatter(min_1, min_2, color='purple', s=100, label='User Coordinate')
    #
    # # 绘制最短路径
    # # 将元组转换为列表
    # longitude_list = list(longitude)
    # # 将最小经度添加到列表末尾
    # longitude_list.append(min_1)
    # # 同理
    # latitude_list = list(latitude)
    # latitude_list.append(min_2)
    # for i in range(len(final_path) - 1):
    #     source, target = final_path[i], final_path[i + 1]
    #     plt.plot([longitude_list[source - 1], longitude_list[target - 1]],
    #              [latitude_list[source - 1], latitude_list[target - 1]], color='black', linestyle='-')
    #
    # # 显示图例，只显示一次
    # plt.legend(loc='upper right')
    #
    # # 显示图形
    # plt.show()
#
# request = create_user_requests_by_userID(1)
# print(request)  # 打印UserRequest对象信息，可选
# args = {
#         'lo': request.Lo,
#         'la': request.La,
#         'route': request.route,
#         'w1': float(request.w1),
#         'w2': float(request.w2),
#         'node_embeddings': node_embeddings
#     }
# A_star_final(**args)


