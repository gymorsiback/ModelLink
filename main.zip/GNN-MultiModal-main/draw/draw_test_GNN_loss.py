import pandas as pd
import matplotlib.pyplot as plt

# 加载数据
df = pd.read_csv('result/GNN_TEST/loss/gnn_embeddings_results_loss.csv')
plt.style.use('tableau-colorblind10')

x_params = ['loss_function']
y_params = ['accuracy_rate', 'average_time', 'robustness_rate']
algorithms = ['ant', 'pso', 'a_star']
colors = ['darkorange', 'red', 'blue']  # 使用颜色列表
labels = ['GNN+ant', 'MultiGen', 'GNN+a_star']

for x_param in x_params:
    for y_param in y_params:
        plt.figure(figsize=(25, 10))

        offset = 0
        offset_step = 0.02

        line_styles = ['--', '-', '-.']
        markers = ['o', 's', '^']

        for idx, algorithm in enumerate(algorithms):
            subset = df[df['algorithm'] == algorithm]
            if subset[x_param].dtype != 'float64' and subset[x_param].dtype != 'int64':
                subset[x_param] = subset[x_param].astype(str)

            subset = subset.sort_values(by=x_param)

            plt.plot(subset[x_param], subset[y_param] + offset,
                     line_styles[idx % len(line_styles)],
                     marker=markers[idx % len(markers)],
                     color=colors[idx],
                     linewidth=2.5,  # 设置所有线条的粗细为 2.5
                     label=labels[idx])
                     # label=f'{algorithm} - {y_param.capitalize()}')

            offset += offset_step

        plt.xticks(rotation=40, ha='right', fontsize=18)
        plt.yticks(fontsize=25)
        plt.legend(fontsize=17, loc='lower center', bbox_to_anchor=(0.5, 1.03), ncol=3, borderaxespad=0.)
        plt.title(f'{y_param.capitalize()} vs. {x_param.capitalize()}', fontsize=30, pad=60)
        plt.xlabel(x_param.capitalize(), fontsize=25, labelpad=-80)
        plt.ylabel(y_param.capitalize(), fontsize=25, labelpad=15)
        plt.grid(True)

        plt.subplots_adjust(bottom=0.3, top=0.85)

        filename = f'result/GNN_TEST/loss/{x_param}_{y_param}_comparison.png'
        plt.savefig(filename)
        plt.show()
