import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

data_folder_path = '../result/PSO/'

# 参数组名称和对应的CSV文件名
param_groups = {
    'Group 1': '10 0.5 1.5 1.2 10 .csv',
    'Group 2': '20 0.4 1 1 20 .csv',
    'Group 3': '20 1.2 1.2 1 20 .csv',
    'Group 4': '30 0.6 1 1.5 30 .csv',
    'Group 5': '30 0.9 1.5 1 10 .csv',
    'Group 6': '40 0.5 2 1.2 20 .csv',
    'Group 7': '40 0.9 0.8 1 10 .csv',
    'Group 8': '40 0.9 2 1.2 20 .csv',
    'Group 9': '50 0.7 2 1.5 30 .csv'
}

# 图例
legend_groups = {
    'Group 1': 'iter=10 w=0.5 s1=1.5 s2=1.2 population_size=10 ',
    'Group 2': 'iter=20 w=0.4 s1=1 s2=1 population_size=20',
    'Group 3': 'iter=20 w=1.2 s1=1.2 s2=1 population_size=20',
    'Group 4': 'iter=30 w=0.6 s1=1 s2=1.5 population_size=30',
    'Group 5': 'iter=30 w=0.9 s1=1.5 s2=1 population_size=10',
    'Group 6': 'iter=40 w=0.5 s1=2 s2=1.2 population_size=20',
    'Group 7': 'iter=40 w=0.9 s1=0.8 s2=1 population_size=10',
    'Group 8': 'iter=40 w=0.9 s1=2 s2=1.2 population_size=20',
    'Group 9': 'iter=50 w=0.7 s1=2 s2=1.5 population_size=30'
}

# 读取CSV文件并提取cost值
cost_data = {name: pd.read_csv(data_folder_path + file)['cost'].values for name, file in param_groups.items()}

# 定义一个颜色列表，每个组一个颜色
colors = ['sandybrown', 'pink', 'deepskyblue', 'blueviolet', 'gold', 'slategray', 'mediumseagreen', 'midnightblue', 'lightcoral', 'orange']  # 添加更多颜色如果需要

# 设置图形大小和样式
plt.figure(figsize=(10, 6))
plt.style.use('seaborn-whitegrid')

# 初始化一个空的代理艺术家列表，用于图例
proxies = []

# 绘制箱型图
positions = range(1, len(param_groups) + 1)  # x轴的位置

for pos, (name, costs) in zip(positions, cost_data.items()):
    color = colors[pos]  # 从颜色列表中获取颜色
    plt.boxplot([costs], positions=[pos], patch_artist=True, boxprops=dict(facecolor=color, color='black'))
    # 为每个箱型图添加一个代理艺术家到列表中
    proxies.append(Patch(facecolor=color, label=legend_groups[name]))

# 使用代理艺术家列表创建图例
legend = plt.legend(handles=proxies, loc='upper right', frameon=True, fontsize=7)
# 设置图例框架的颜色为白色
legend.get_frame().set_facecolor('white')

# 设置x轴和y轴的标签
plt.xlabel('Parameter Groups', fontsize=20, labelpad=20)
plt.ylabel('Cost', fontsize=20, labelpad=20)

# 显示图形
plt.xticks(positions, param_groups.keys(), fontsize=15)  # 设置x轴刻度标签为参数组名称
plt.yticks(fontsize=15)
plt.grid(True)
plt.title("Cost vs. Time", fontsize=25)
# plt.tight_layout()  # 调整布局以避免重叠
plt.show()

