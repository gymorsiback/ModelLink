from matplotlib import pyplot as plt
import pandas as pd

# 加载数据
df = pd.read_csv('result/GNN_TEST/activation_function/gnn_embeddings_results_activation_function.csv')
plt.style.use('tableau-colorblind10')

# 横坐标参数列表
x_params = ['activation_function']

# 纵坐标参数列表
y_params = ['accuracy_rate', 'average_time']

# 算法列表
algorithms = ['ant', 'pso', 'a_star']
colors = ['darkorange', 'red', 'blue']  # 定义颜色列表
labels = ['GNN+ant', 'MultiGen', 'GNN+a_star']

for x_param in x_params:
    for y_param in y_params:
        plt.figure(figsize=(14, 10))  # 增大图表尺寸

        offset = 0
        offset_step = 0.02

        line_styles = ['--', '-', '-.']
        markers = ['o', 's', '^']
        linewidths = [2.5, 2.5, 2.5]  # 定义线段粗细

        for idx, algorithm in enumerate(algorithms):
            subset = df[df['algorithm'] == algorithm]
            if subset[x_param].dtype != 'float64' and subset[x_param].dtype != 'int64':
                subset[x_param] = subset[x_param].astype(str)

            subset = subset.sort_values(by=x_param)

            plt.plot(subset[x_param], subset[y_param] + offset,
                     line_styles[idx % len(line_styles)],
                     marker=markers[idx % len(markers)],
                     color=colors[idx],  # 使用颜色列表中的颜色
                     linewidth=linewidths[idx],  # 设置线段粗细
                     label=labels[idx])
                     # label=f'{algorithm} - {y_param.capitalize()}')

            offset += offset_step

        plt.xticks(rotation=25, ha='right', fontsize=20)
        plt.yticks(fontsize=20)
        plt.legend(fontsize=15, loc='lower center', bbox_to_anchor=(0.5, 1.03), ncol=3, borderaxespad=0.)
        plt.title(f'{y_param.capitalize()} vs. {x_param.capitalize()}', fontsize=25, pad=57)
        plt.xlabel(x_param.capitalize(), fontsize=20, labelpad=10)
        plt.ylabel(y_param.capitalize(), fontsize=20, labelpad=15)
        plt.grid(True)

        plt.subplots_adjust(bottom=0.2, top=0.85)

        filename = f'result/GNN_TEST/activation_function/{x_param}_{y_param}_comparison.png'
        plt.savefig(filename)
        plt.show()
