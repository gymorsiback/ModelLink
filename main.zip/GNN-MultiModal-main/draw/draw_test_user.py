import pandas as pd
import matplotlib.pyplot as plt

# Load data into a DataFrame
df = pd.read_csv('result/results_user_perference.csv')
# plt.style.use('seaborn-darkgrid')
plt.style.use('tableau-colorblind10')
colors = ['darkorange', 'red', 'blue']
algorithms = ['ant', 'pso', 'a_star']
# x_params = ['W1']
x_params = ['user_prefer_w1']


# Define the metrics for y-axis
y_params = ['accuracy_rate', 'average_time', 'robustness_rate']
# labels = ['Ant', 'MutiGen', 'A*']
labels = ['GNN+ant', 'MultiGen', 'GNN+a_star']

# # Generate plots
# for metric in metrics:
#     plt.figure(figsize=(10, 6))
#     for algorithm in df['algorithm'].unique():
#         subset = df[df['algorithm'] == algorithm]
#         plt.plot(subset['user_prefer_w1'], subset[metric], label=algorithm)
#     plt.xlabel('W1')
#     plt.ylabel(metric)
#     plt.title(f'{metric} vs. W1')
#     plt.legend()
#     plt.show()

for x_param in x_params:
    for y_param in y_params:
        plt.figure(figsize=(16, 10))

        offset = 0
        offset_step = 0.02

        line_styles = ['--', '-', '-.']
        markers = ['o', 's', '^']

        for idx, algorithm in enumerate(algorithms):
            subset = df[df['algorithm'] == algorithm]
            if subset[x_param].dtype != 'float64' and subset[x_param].dtype != 'int64':
                subset[x_param] = subset[x_param].astype(str)

            subset = subset.sort_values(by=x_param)

            plt.plot(subset[x_param], subset[y_param] + offset,
                     line_styles[idx % len(line_styles)],
                     marker=markers[idx % len(markers)],
                     color=colors[idx % len(colors)],  # 应用颜色列表中的颜色
                     linewidth=2.5,  # 设置线条粗细为 2.5
                    #  label=f'{algorithm} - {y_param.capitalize()}')
                    label = labels[idx]
            )

            offset += offset_step

        plt.xticks(rotation=40, ha='right', fontsize=25)
        plt.yticks(fontsize=25)
        plt.legend(fontsize=17, loc='lower center', bbox_to_anchor=(0.5, 1.03), ncol=3, borderaxespad=0.)
        plt.title(f'{y_param.capitalize()} vs. {x_param.capitalize()}', fontsize=30, pad=60)
        plt.xlabel(x_param.capitalize(), fontsize=25, labelpad=16)
        plt.ylabel(y_param.capitalize(), fontsize=25, labelpad=16)
        plt.grid(True)
        plt.subplots_adjust(bottom=0.3, top=0.85)

        filename = f'result/user/{x_param}_{y_param}_comparison.png'
        plt.savefig(filename)
        plt.show()
