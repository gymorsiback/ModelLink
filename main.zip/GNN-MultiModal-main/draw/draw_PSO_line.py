import pandas as pd
import matplotlib.pyplot as plt
import sys
import os
# sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

x1 = 'iter'
x2 = 'population_size'
y1 = 'accuracy_rate'
y2 = 'robustness_rates'
path = 'result/PSO/pso_ws_results.csv'

# 读取CSV文件
df_read = pd.read_csv(path)

# 根据特定列进行排序
# ascending=True表示升序，ascending=False表示降序
df_sort = df_read.sort_values(by=x2, ascending=True)

# 去除重复行，keep参数决定如何处理重复行
# keep='first'保留第一次出现的行，'last'保留最后一次出现的行，False则全部删除
df = df_sort.drop_duplicates(keep='first')

# 筛选
# df_filtered = df[(df['w'] == 0.9) & (df['iter'] == 30) & (df['population_size'] == 200)]
df_filtered = df[(df['w'] == 0.9) & (df['s1'] == 2) & (df['s2'] == 1.2)]

# 对x1进行分组
grouped = df_filtered.groupby(x1)

# 准备绘图
fig, ax1 = plt.subplots(figsize=(10, 6))
# 创建共享x轴的第二个y轴用于y2
# ax2 = ax1.twinx()
colors = ['b', 'g', 'r', 'c', 'm', 'y', 'k']  # 假设有足够多的颜色用于区分不同的组
line_styles = ['-', '--', '-.', ':']  # 不同的线型，如果需要更多线型可以添加更多
marker_styles = ['o', '^']  # 不同的标记，圆点和三角形


# 遍历每个组并绘制折线
for i, (name, group) in enumerate(grouped):
    # 绘制y1的折线
    ax1.plot(group[x2], group[y1], color=colors[i % len(colors)],
             linestyle=line_styles[i % len(line_styles)],
             label=x1 + ' = ' + f'{name}'+' ', marker=marker_styles[0])


    # 绘制y2的折线
    # ax2.plot(group[x2], group[y2], color=colors[i % len(colors)],
    #          linestyle=line_styles[i % len(line_styles)],
    #          label=x1 + f' {name}'+' '+y2, marker=marker_styles[1])

    # 设置图例
    a1 = ax1.legend(loc='lower right', borderaxespad=0.5)
    # a2 = ax2.legend(bbox_to_anchor=(0.95, 1.1), loc='upper right', borderaxespad=0.)

    # 调整图例字体大小
    for text in a1.get_texts():
        text.set_fontsize(12)  # 或者使用具体的数值，如8
    # for text in a2.get_texts():
    #     text.set_fontsize('small')  # 或者使用具体的数值，如8
    for line in a1.get_lines():
        line.set_linewidth(1.5)  # 调整线条粗细
    # for line in a2.get_lines():
    #     line.set_linewidth(1.5)  # 调整线条粗细

'''
# 单变量
# 绘制y1的折线
ax1.plot(df_filtered[x2], df_filtered[y1], color='blue',
        # linestyle=line_styles[i % len(line_styles)],
        label=y1, marker=marker_styles[0])


# 绘制y2的折线
ax2.plot(df_filtered[x2], df_filtered[y2], color='purple',
        # linestyle=line_styles[i % len(line_styles)],
         label=y2, marker=marker_styles[1])
# 设置图例
a1 = ax1.legend(bbox_to_anchor=(0.05, 1.1), loc='upper left', borderaxespad=0.)
a2 = ax2.legend(bbox_to_anchor=(0.95, 1.1), loc='upper right', borderaxespad=0.)

# 调整图例字体大小
for text in a1.get_texts():
    text.set_fontsize('small')  # 或者使用具体的数值，如8
for text in a2.get_texts():
    text.set_fontsize('small')  # 或者使用具体的数值，如8
for line in a1.get_lines():
    line.set_linewidth(1.5)  # 调整线条粗细
for line in a2.get_lines():
    line.set_linewidth(1.5)  # 调整线条粗细
'''
# 设置y轴的标签
ax1.set_ylabel("Accuracy_rate",fontsize=15)
# ax2.set_ylabel(y2)
ax1.set_xlabel(x2,fontsize=15)
plt.grid(True)
plt.title("Accuracy_rate vs Population", fontsize=18)
# 显示图表
# plt.tight_layout()
plt.show()






