import pandas as pd
import matplotlib.pyplot as plt

# 加载数据
df = pd.read_csv('result/ant_test_Q_results.csv')


df_q10 = df[df['Q'] == 10]

# 筛选 Q = 10 的数据
df_q10 = df[df['Q'] == 10]

# 绘制图表
plt.figure(figsize=(12, 8))

# 柱状图绘制accuracy_rate
plt.bar(df_q10['rho'], df_q10['accuracy_rate'], color='blue', label='Accuracy Rate', alpha=0.6, width=0.03)
plt.xlabel('Rho')
plt.ylabel('Accuracy Rate', color='blue')
plt.ylim(0.75, 0.85)  # 设置左侧纵轴的显示范围，以侧重于0.8附近的数据

# 创建右侧纵轴
ax2 = plt.gca().twinx()

# 折线图绘制robustness_rate
ax2.plot(df_q10['rho'], df_q10['robustness_rate'], color='red', marker='o', label='Robustness Rate', linewidth=2)
ax2.set_ylabel('Robustness Rate', color='red')
ax2.set_ylim(0.95, 1.05)  # 设置右侧纵轴的显示范围，以确保顶部为1

# 设置图表标题
plt.title('Performance Metrics vs. Rho (Q = 10)')

# 设置x轴的刻度为rho列中的唯一值
plt.xticks(df_q10['rho'].unique())

# 添加图例
plt.legend(loc='upper left')
ax2.legend(loc='upper right')

plt.grid(True)

# 保存图表
plt.savefig('result/ant_test_Q/rho_metrics_comparison_q10.png')
plt.show()