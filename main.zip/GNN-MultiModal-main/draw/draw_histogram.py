from matplotlib import pyplot as plt
import pandas as pd
import numpy as np
# import sys
# import os
# sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# 加载数据
# df = pd.read_csv('../result/GNN_TEST/activation_function/gnn_embeddings_results_activation_function.csv')
# df = pd.read_csv('../result/GNN_TEST/epochs/gnn_embeddings_results_epoch.csv')
# df = pd.read_csv('../result/GNN_TEST/loss/gnn_embeddings_results_loss.csv')
df = pd.read_csv('../result/GNN_TEST/optimizer/gnn_embeddings_results_optimizer.csv')
plt.style.use('tableau-colorblind10')

# # 横坐标参数列表
# x_params = ['activation_function']
# x_params = ['epochs']
# x_params = ['loss_function']
x_params = ['optimizer']
# # 纵坐标参数列表
y_params = ['accuracy_rate', 'average_time', 'robustness_rate']

# 算法列表
algorithms = ['ant', 'pso', 'a_star']
colors = ['deepskyblue', 'tomato', 'palegreen']  # 定义颜色列表
labels = ['GNN+ant', 'MultiGen', 'GNN+a_star']

for x_param in x_params:
    Abscissa = sorted(set(df[x_param]))  # 确保横坐标是排序后的唯一值
    Abscissa_dict = {val: idx for idx, val in enumerate(Abscissa)}  # 创建一个字典，用于将横坐标值映射到索引

    x = np.arange(len(Abscissa))
    for y_param in y_params:
        plt.figure(figsize=(16, 10))  # 增大图表尺寸
        # 设置直方图的宽度
        width = 0.25
        for idx, algorithm in enumerate(algorithms):
            subset = df[df['algorithm'] == algorithm]
            subset = subset[subset[x_param].isin(Abscissa)]  # 确保subset只包含Abscissa中的x_param值
            subset = subset.sort_values(by=x_param)

            # 计算每个算法对应的y值列表
            y_values = subset[y_param].tolist()

            plt.bar(x + idx * width - width/2, y_values, width=width, color=colors[idx], label=labels[idx])

        plt.legend(fontsize=15, loc='lower center', bbox_to_anchor=(0.5, 1.03), ncol=3, borderaxespad=0.)
        plt.title(f'{y_param.capitalize()} vs. {x_param.capitalize()}', fontsize=25, pad=57)
        plt.xticks(x + width * len(algorithms) / 2, Abscissa, rotation=20, ha='right', fontsize=10)  # 将x轴标签居中
        plt.yticks(fontsize=20)
        plt.xlabel(x_param.capitalize(), fontsize=20, labelpad=10)
        plt.ylabel(y_param.capitalize(), fontsize=20, labelpad=15)
        plt.grid(True)

        plt.subplots_adjust(bottom=0.2, top=0.85)

        # filename = f'../result/GNN_TEST/histogram/activation_function/{x_param}_{y_param}_comparison.png'
        # filename = f'../result/GNN_TEST/histogram/epochs/{x_param}_{y_param}_comparison.png'
        # filename = f'../result/GNN_TEST/histogram/loss/{x_param}_{y_param}_comparison.png'
        filename = f'../result/GNN_TEST/histogram/optimizer/{x_param}_{y_param}_comparison.png'
        plt.savefig(filename)
        plt.show()

