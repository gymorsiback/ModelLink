import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import sys
import os

# 设置文件路径
path = '../result/GNN_TEST/all-box/all.csv'
# 读取 CSV 文件并加载到 DataFrame 中
df = pd.read_csv(path)

# 根据算法类型对数据进行分组，并计算 accuracy_rate 列的统计量
grouped = df.groupby('algorithm')['accuracy_rate'].describe()

# 设置 x 坐标
algorithm_mapping = {'a_star': 'GNN+a_star', 'pso': 'MultiGen', 'ant': 'GNN+ant'}
df['algorithm_mapped'] = df['algorithm'].map(algorithm_mapping)

# 使用 seaborn 绘制箱型图
plt.figure(figsize=(10, 6))
sns.boxplot(x='algorithm_mapped', y='accuracy_rate', data=df, palette=['lightyellow', 'lightpink', 'lightblue'])
plt.title('Boxplot of Accuracy Rate by Algorithm', fontsize=18)
plt.xlabel('Algorithm', fontsize=15)
plt.ylabel('Accuracy Rate', fontsize=15)
plt.xticks(rotation=0)

plt.show()

# 根据算法类型对数据进行分组，并计算 accuracy_rate 列的统计量
grouped = df.groupby('algorithm')['average_time'].describe()

# 设置 x 坐标
algorithm_mapping = {'a_star': 'GNN+a_star', 'pso': 'MultiGen', 'ant': 'GNN+ant'}
df['algorithm_mapped'] = df['algorithm'].map(algorithm_mapping)

# 使用 seaborn 绘制箱型图
plt.figure(figsize=(10, 6))
sns.boxplot(x='algorithm_mapped', y='average_time', data=df, palette=['lightyellow', 'lightpink', 'lightblue'])
plt.title('Boxplot of Average Time by Algorithm', fontsize=18)
plt.xlabel('Algorithm', fontsize=15)
plt.ylabel('Average Time', fontsize=15)
plt.xticks(rotation=0)

plt.show()

# 根据算法类型对数据进行分组，并计算 accuracy_rate 列的统计量
grouped = df.groupby('algorithm')['robustness_rate'].describe()

# 设置 x 坐标
algorithm_mapping = {'a_star': 'GNN+a_star', 'pso': 'MultiGen', 'ant': 'GNN+ant'}
df['algorithm_mapped'] = df['algorithm'].map(algorithm_mapping)

# 使用 seaborn 绘制箱型图
plt.figure(figsize=(10, 6))
sns.boxplot(x='algorithm_mapped', y='robustness_rate', data=df, palette=['lightyellow', 'lightpink', 'lightblue'])
plt.title('Boxplot of Robustness Rate by Algorithm', fontsize=18)
plt.xlabel('Algorithm', fontsize=15)
plt.ylabel('Average Time', fontsize=15)
plt.xticks(rotation=0)

plt.show()
