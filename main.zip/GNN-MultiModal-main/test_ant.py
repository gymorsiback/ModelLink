from utils import *
# from Particle_GNN import *
from userRequest import *
from dataPreprocess import *
# from A_star import *
import argparse
from Ant_test import *
# from GA_GNN import *
from BFS import *
import matplotlib.pyplot as plt
import timeit
from collections import Counter

alpha_list = [0.5, 1, 1.5]
beta_list = [0.5, 1, 1.5]
Q_list = [10, 50, 100, 150, 200]
rho_list = [0.1, 0.2, 0.3, 0.4, 0.5]
nums_ant_list = [10, 30, 50]
# 准确率测试和时间测试的通用算法调用函数
def run_algorithm(algorithm, request, alpha, beta, Q, rho, nums_ant):
    algorithms = {
        # 'a_star': A_star_final,
        'ant': test_Ant_final,
        # 'pso': PSO,
        # 'ga': GA,
        'bfs': BFS
    }

    function = algorithms.get(algorithm)
    if function:
        return function(request.Lo, request.La, request.route, float(request.w1), float(request.w2), alpha, beta, Q, rho, nums_ant)
    else:
        print(f"Unknown algorithm: {algorithm}")
        return None


# 准确率测试函数
def test_accuracy(user_id, algorithm, alpha, beta, Q, rho, nums_ant):
    request = create_user_requests_by_userID(user_id)
    path1 = BFS(request.Lo, request.La, request.route, float(request.w1), float(request.w2))
    path2 = run_algorithm(algorithm, request, alpha, beta, Q, rho, nums_ant)

    return 1 if path1[1:-1] == path2[1:-1] else 0


# 鲁棒性测试函数，运行20次取平均
# 在 test_robustness 函数中，修改 results 列表的处理方式
def test_robustness(algorithm, alpha, beta, Q, rho, nums_ant, user_id=1, repetitions=20):
    request = create_user_requests_by_userID(user_id)
    results = []

    for _ in range(repetitions):
        result = run_algorithm(algorithm, request, alpha, beta, Q, rho, nums_ant)
        results.append(result)

    # 将列表中的列表转换为元组，使其可哈希
    hashable_results = [tuple(r) if isinstance(r, list) else r for r in results]

    # 然后计算最常见结果的频率
    most_common_result, count = Counter(hashable_results).most_common(1)[0]
    return count / repetitions

# 主测试函数
def main():
    user_ids = range(1, 101)
    algorithms = ['ant']
    accuracy_counts = {alg: 0 for alg in algorithms}
    # total_times = {alg: 0 for alg in algorithms}
    robustness_rates = {alg: 0 for alg in algorithms}
    results = []
    for algorithm in algorithms:
        for nums_ant in nums_ant_list:
            for alpha in alpha_list:
                for beta in beta_list:
                    for Q in Q_list:
                        for rho in rho_list:
                            accuracy_counts[algorithm] = 0
                            for user_id in user_ids:
                                request = create_user_requests_by_userID(user_id)
                                # 准确率测试
                                accuracy_counts[algorithm] += test_accuracy(user_id, algorithm, alpha, beta, Q, rho, nums_ant)
                                # 仅对 user_id 为 1 的情况测试鲁棒性
                                if user_id == 1:
                                    robustness_rates[algorithm] = test_robustness(algorithm, alpha, beta, Q, rho, nums_ant)
                            accuracy_rates = {alg: accuracy_counts[alg] / len(user_ids) for alg in algorithms}
                            result = {
                                'alpha': alpha,
                                'beta': beta,
                                'Q': Q,
                                'rho': rho,
                                'nums_ant': nums_ant,
                                'accuracy_count': accuracy_counts[algorithm],
                                'accuracy_rate': accuracy_rates[algorithm],
                                'robustness_rate': robustness_rates.get(algorithm, None),  # 使用get以防某些算法没有鲁棒性评分
                            }
                            results.append(result)
                            print("-------------------")
    df = pd.DataFrame(results)
    df.to_csv('result/ant_test2_results.csv', index=False)

    # # 计算并绘制准确率图
    # accuracy_rates = {alg: accuracy_counts[alg] / len(user_ids) for alg in algorithms}
    # plt.figure(figsize=(10, 6))
    # plt.plot(['BFS'] + list(accuracy_rates.keys()), [1.0] + list(accuracy_rates.values()), marker='o', linestyle='-')
    # plt.title('Algorithm Accuracy Comparison')
    # plt.xlabel('Algorithm')
    # plt.ylabel('Accuracy Rate')
    # plt.grid(True)
    # plt.show()
    #
    # # 计算并绘制执行时间图
    # average_times = {alg: total_times[alg] / len(user_ids) for alg in algorithms}
    # plt.figure(figsize=(10, 6))
    # plt.plot(average_times.keys(), average_times.values(), marker='o', linestyle='-')
    # plt.title('Average Execution Time for Algorithms')
    # plt.xlabel('Algorithm')
    # plt.ylabel('Average Time (seconds)')
    # plt.grid(True)
    # plt.show()
    #
    # # 绘制鲁棒性图
    # plt.figure(figsize=(10, 6))
    # plt.plot(robustness_rates.keys(), robustness_rates.values(), marker='o', linestyle='-')
    # plt.title('Robustness of Algorithms')
    # plt.xlabel('Algorithm')
    # plt.ylabel('Robustness Rate')
    # plt.grid(True)
    # plt.show()


# 运行主测试函数
if __name__ == "__main__":
    main()