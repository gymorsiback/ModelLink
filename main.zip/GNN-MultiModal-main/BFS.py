from dataPreprocess import *
from collections import defaultdict
from GNN import *
import numpy as np
import heapq


def BFS(lo, la, route, w1, w2, node_embeddings,edge=edge,edge_features=edge_features,locations=locations,model_performence=model_performence):
    # 将列表解析成经度和纬度的两个列表
    import copy
    edge_copy = copy.deepcopy(edge)
    edge_features_copy = copy.deepcopy(edge_features)
    locations_copy = copy.deepcopy(locations)
    model_performence_copy = copy.deepcopy(model_performence)

    longitude, latitude = zip(*locations_copy)
    route.insert(0, len(locations_copy) + 1)
    route.append(len(locations_copy) + 1)
    # 计算[lo,la]到locations中所有坐标的距离
    distance = [haversine(lo, la, lon, lat) for lon, lat in zip(longitude, latitude)]
    edge_copy = edge_copy.tolist()
    edge_features_copy = edge_features_copy.tolist()

    # 将[lo,la]到所有其他节点的边添加到 edge 中
    for i in range(len(locations_copy)):
        # 可去
        edge_copy[0].append(len(locations_copy) + 1)  # 17 号点的索引
        edge_copy[1].append(i + 1)
        # 可回
        edge_copy[0].append(i + 1)
        edge_copy[1].append(len(locations_copy) + 1)
    # 复制每个元素并放在原元素的后面
    distance_copy = np.repeat(distance, 2)

    # 将相应的距离添加到 edge_features 中
    edge_features_flat = [item for sublist in edge_features_copy for item in sublist]
    edge_features_flat.extend(distance_copy)  # 可以把每条边target点上耽误的时间都算进这条边的距离中，具体计算为这条边对应target点的(c1/server_performence + c2/model_efficiency)加到对应的edge_features_flat中
    node_efficiency = []

    # 权重，根据测试自己调整
    c1 = 1
    c2 = 0.1
    c3 = 1
    # model_performence
    for i in range(len(model_efficiency)):
        node_efficiency.append(c1 / (server_performence[i] * model_efficiency[i]))  # (c1 / server_performence[i]) + (c2 / model_efficiency[i])
    node_efficiency = [float(value) for value in node_efficiency]
    second_elements = [sub_array[1] for sub_array in model_performence_copy]  # second_elements是model_performence中元素的第二个元素
    for i in range(len(edge_copy[1])):
        if edge_copy[1][i] == len(locations_copy) + 1:
            edge_features_flat[i] += 0
        else:
            edge_features_flat[i] = w1 * (node_efficiency[edge_copy[1][i] - 1] + c2 * edge_features_flat[i]) + w2 * (c3 / second_elements[edge_copy[1][i] - 1])
    # print("edge =", edge)
    # print("edge_features_flat =", edge_features_flat)
    Y_copy = copy.deepcopy(Y)
    Y_copy.append(len(locations_copy) + 1)
    # print(Y_copy)
    # Initialize the route_pro array
    route_pro = []
    # Fill route_pro based on the condition
    for r in route:
        indices = [i + 1 for i, y in enumerate(Y_copy) if y == r]
        route_pro.append(indices)
    # print(route_pro)

    from collections import deque

    def construct_graph(edge, edge_features_flat):
        graph = {}
        for start, end, cost in zip(edge[0], edge[1], edge_features_flat):
            if start not in graph:
                graph[start] = {}
            graph[start][end] = cost
        return graph

    def bfs_search(graph, route_pro):
        queue = deque([(node, [node], 0) for node in route_pro[0]])
        min_cost = float('inf')
        optimal_path = None

        while queue:
            current_node, path, total_cost = queue.popleft()

            if len(path) == len(route_pro) and current_node == path[-1]:
                if total_cost < min_cost:
                    min_cost = total_cost
                    optimal_path = path
                continue

            if len(path) < len(route_pro):
                next_group = route_pro[len(path)]
                for next_node in next_group:
                    if current_node in graph and next_node in graph[current_node]:
                        new_cost = total_cost + graph[current_node][next_node]
                        queue.append((next_node, path + [next_node], new_cost))

        return optimal_path, min_cost

    def find_optimal_path(edge, edge_features_flat, route_pro):
        graph = construct_graph(edge, edge_features_flat)
        optimal_path, cost = bfs_search(graph, route_pro)
        return optimal_path, cost

    path, cost = find_optimal_path(edge_copy, edge_features_flat, route_pro)
    # print(f"BFS Path: {path}, Cost: {cost}")
    route.pop(0)
    route.pop()
    return path

    # ''''''
    # # 使用默认字典收集每个类别的坐标
    # category_coordinates = defaultdict(list)
    #
    # for lon, lat, category in zip(longitude, latitude, Y):
    #     category_coordinates[category].append((lon, lat))
    #
    # # 绘制散点图
    # plt.figure(figsize=(10, 8))
    #
    # # 遍历类别字典，绘制相同类别的坐标使用相同颜色
    # for category, coordinates in category_coordinates.items():
    #     color = plt.cm.jet(category / max(Y))  # 使用viridis颜色映射
    #     plt.scatter(*zip(*coordinates), color=color, s=50, label=f'Category {category}')
    #
    # # 添加标签和标题
    # plt.xlabel('Longitude')
    # plt.ylabel('Latitude')
    # plt.title('Scatter Plot of Coordinates')
    #
    # # 绘制用户点
    # plt.scatter(lo, la, color='purple', s=100, label='User Coordinate')
    #
    # # 绘制最短路径
    # # 将元组转换为列表
    # longitude_list = list(longitude)
    # # 将最小经度添加到列表末尾
    # longitude_list.append(lo)
    # # 同理
    # latitude_list = list(latitude)
    # latitude_list.append(la)
    # for i in range(len(path) - 1):
    #     source, target = path[i], path[i + 1]
    #     plt.plot([longitude_list[source - 1], longitude_list[target - 1]],
    #              [latitude_list[source - 1], latitude_list[target - 1]], color='black', linestyle='-')
    #
    # # 显示图例，只显示一次
    # plt.legend(loc='upper right')
    #
    # # 显示图形
    # plt.show()
