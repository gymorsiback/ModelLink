# GA (Genetic Algorithm) for GNN (Graph Neural Network) hyperparameter optimization
import random
import numpy as np
from dataPreprocess import * 
from GNN import *
from collections import defaultdict


# def calculate_fitness(individual, graph, costs, node_embeddings):
#     """
#     计算给定个体的适应度。
#     individual: 染色体（路径）
#     graph: 图表示
#     costs: 边的成本
#     node_embeddings: 节点嵌入向量
#     """
#     # 这里的适应度计算可以根据问题的具体需求进行调整
#     path_cost = sum(costs.get((individual[i], individual[i + 1]), float('inf')) for i in range(len(individual) - 1))
#     return 1 / path_cost  # 适应度值越大表示路径成本越低



# def calculate_fitness(individual, graph, costs, node_embeddings):
#     # 初始化路径成本为0
#     path_cost = 0

#     # 计算路径成本
#     for i in range(len(individual) - 1):
#         edge_cost = costs.get((individual[i], individual[i + 1]), float('inf'))
#         # 确保edge_cost是一个标量
#         if isinstance(edge_cost, (list, np.ndarray)):
#             edge_cost = edge_cost[0] if edge_cost else float('inf')
#         path_cost += edge_cost

#     # 使用node_embeddings来评估路径的额外特性
#     embeddings_similarity = sum(torch.norm(node_embeddings[individual[i]] - node_embeddings[individual[i + 1]], p=2).item()
#                                 for i in range(len(individual) - 1))

#     # 综合考虑路径成本和节点嵌入的相似度来计算适应度
#     fitness = 1 / (path_cost + embeddings_similarity) if path_cost != float('inf') else 0

#     # 确保fitness是标量
#     assert isinstance(fitness, (int, float)), "Fitness must be a scalar"

#     return fitness

def calculate_fitness(individual, graph, costs, node_embeddings):
    individual = [item - 1 for item in individual]
    user_node_index = len(node_embeddings) - 1  # 用户节点的索引
    path_distance = 0
    embeddings_similarity = 0
    print(f'Individual: {individual}')
    print(f'user_node_index: {user_node_index}')

    for i in range(len(individual) - 1):
        # 计算距离成本
        if (individual[i], individual[i + 1]) in costs:
            path_distance += costs[(individual[i], individual[i + 1])]
        else:
            path_distance += float('inf')  # 如果没有直接路径，成本设为无穷大
            
        # print(f'Cost from {individual[i]} to {individual[i+1]}: {costs.get((individual[i], individual[i + 1]), float("inf"))}')

        # 计算嵌入相似度，跳过用户节点
        if individual[i] != user_node_index and individual[i + 1] != user_node_index:
            embeddings_similarity += torch.norm(node_embeddings[individual[i]] - node_embeddings[individual[i + 1]], p=2).item()
            # print(f'Embeddings similarity from {individual[i]} to {individual[i+1]}: {embeddings_similarity}')

    # 打印总路径距离和嵌入相似度
    # print(f'Total path distance: {path_distance}')
    # print(f'Total embeddings similarity: {embeddings_similarity}')

    # 这里的适应度计算方式是示例，可能需要根据问题调整
    fitness = 1 / (path_distance + 1 / (embeddings_similarity + 1)) if path_distance < float('inf') else 0

    # 打印最终适应度
    print(f'Fitness: {fitness}')

    # 这里的适应度计算方式是示例，可能需要根据问题调整
    # fitness = 1 / (path_distance + 1 / (embeddings_similarity + 1)) if path_distance < float('inf') else 0

    return fitness








def init_population(pop_size, graph):
    """
    初始化种群
    """
    population = []
    for _ in range(pop_size):
        individual = list(graph.keys())
        random.shuffle(individual)
        population.append(individual)
    return population

# def select(population, fitnesses, selection_size):
#     """
#     轮盘赌选择
#     """
#     selected_indices = np.random.choice(len(population), size=selection_size, p=fitnesses/np.sum(fitnesses))
#     return [population[i] for i in selected_indices]
def select(population, fitnesses, selection_size):
    """
    轮盘赌选择
    """
    total_fitness = np.sum(fitnesses)
    if total_fitness == 0:
        # 如果总适应度为0，则均等选择
        selected_indices = np.random.choice(len(population), size=selection_size)
    else:
        # 计算每个个体被选中的概率
        probabilities = fitnesses / total_fitness
        selected_indices = np.random.choice(len(population), size=selection_size, p=probabilities)
    return [population[i] for i in selected_indices]


def crossover(parent1, parent2):
    """
    单点交叉
    """
    crossover_point = random.randint(1, len(parent1) - 2)
    child1 = parent1[:crossover_point] + parent2[crossover_point:]
    child2 = parent2[:crossover_point] + parent1[crossover_point:]
    return child1, child2

def mutate(individual, mutation_rate):
    """
    突变操作
    """
    for i in range(len(individual)):
        if random.random() < mutation_rate:
            j = random.randint(0, len(individual) - 1)
            individual[i], individual[j] = individual[j], individual[i]

def genetic_algorithm(graph, costs, node_embeddings, pop_size=100, generations=50, mutation_rate=0.01):
    population = init_population(pop_size, graph)
    for generation in range(generations):
        fitnesses = np.array([calculate_fitness(individual, graph, costs, node_embeddings) for individual in population])
        selected = select(population, fitnesses, len(population) // 2)
        offspring = []
        for i in range(0, len(selected), 2):
            child1, child2 = crossover(selected[i], selected[i + 1])
            mutate(child1, mutation_rate)
            mutate(child2, mutation_rate)
            offspring.append(child1)
            offspring.append(child2)
        population = selected + offspring

    # 找到最佳解
    best_individual = max(population, key=lambda ind: calculate_fitness(ind, graph, costs, node_embeddings))
    return best_individual

# 创建图和成本
# graph, costs = create_graph_and_costs(edge, edge_features)

# 运行遗传算法
# best_path = genetic_algorithm(graph, costs, node_embeddings)
# print("Best path found by GA:", best_path)


def GA(min_1,min_2,route,w1=0.5,w2=0.5,edge=edge,edge_features=edge_features,locations=locations,model_performence=model_performence):
    # 创建图和成本
    longitude, latitude = zip(*locations)
    
    route.insert(0, len(locations)+1)
    route.append(len(locations)+1)
    # 计算[min_1,min_2]到locations中所有坐标的距离
    distance = [haversine(min_1, min_2, lon, lat) for lon, lat in zip(longitude, latitude)]
    edge = edge.tolist()
    edge_features = edge_features.tolist()

    # 将[min_1,min_2]到所有其他节点的边添加到 edge 中
    for i in range(len(locations)):
        # 可去
        edge[0].append(len(locations) + 1)  # 17 号点的索引
        edge[1].append(i + 1)
        # 可回
        edge[0].append(i + 1)
        edge[1].append(len(locations) + 1)
    # 复制每个元素并放在原元素的后面
    distance_copy = np.repeat(distance, 2)

    # 将相应的距离添加到 edge_features 中
    edge_features_flat = [item for sublist in edge_features for item in sublist]
    edge_features_flat.extend(
        distance_copy)  # 可以把每条边target点上耽误的时间都算进这条边的距离中，具体计算为这条边对应target点的(c1/server_performence + c2/model_efficiency)加到对应的edge_features_flat中
    node_efficiency = []
    # 权重，根据测试自己调整
    c1 = 1
    c2 = 1
    c3 = 1
    # model_performence
    for i in range(len(model_efficiency)):
        node_efficiency.append((c1 / server_performence[i]) + (c2 / model_efficiency[i]))
    node_efficiency = [float(value) for value in node_efficiency]
    second_elements = [sub_array[1] for sub_array in model_performence] # second_elements是model_performence中元素的第二个元素
    for i in range(len(edge[1])):
        if edge[1][i] == len(locations)+1:
            edge_features_flat[i] += 0
        else:
            edge_features_flat[i] += w1 * node_efficiency[edge[1][i] - 1] + w2 * (c3 / second_elements[edge[1][i] - 1])
    # print("edge =", edge)
    # print("edge_features_flat =", edge_features_flat)
    Y.append(len(locations) + 1)
    # print(Y)
    # Initialize the route_pro array
    route_pro = []
    # Fill route_pro based on the condition
    for r in route:
        indices = [i + 1 for i, y in enumerate(Y) if y == r]
        route_pro.append(indices)
    print(route_pro)

    locations.append([min_1, min_2])
    # route = [17,1,2,3,17]
    # locations.append([min_1,min_2])
    # node_positions = {i + 1: (lon, lat) for i, (lon, lat) in enumerate(locations)}
    # print("node_positions =", node_positions)
    graph, costs = create_graph_and_costs(edge, edge_features_flat)

    # 运行遗传算法
    final_path = genetic_algorithm(graph, costs, node_embeddings)
    return final_path

    # 展示最佳路径
    category_coordinates = defaultdict(list)

    for lon, lat, category in zip(longitude, latitude, Y):
        category_coordinates[category].append((lon, lat))

    # 绘制散点图
    plt.figure(figsize=(10, 8))

    # 遍历类别字典，绘制相同类别的坐标使用相同颜色
    for category, coordinates in category_coordinates.items():
        color = plt.cm.jet(category / max(Y))  # 使用viridis颜色映射
        plt.scatter(*zip(*coordinates), color=color, s=50, label=f'Category {category}')

    # 添加标签和标题
    plt.xlabel('Longitude')
    plt.ylabel('Latitude')
    plt.title('Scatter Plot of Coordinates')

    # 绘制用户点
    plt.scatter(min_1, min_2, color='purple', s=100, label='User Coordinate')

    # 绘制最短路径
    # 将元组转换为列表
    longitude_list = list(longitude)
    # 将最小经度添加到列表末尾
    longitude_list.append(min_1)
    # 同理
    latitude_list = list(latitude)
    latitude_list.append(min_2)
    for i in range(len(final_path) - 1):
        source, target = final_path[i], final_path[i + 1]
        plt.plot([longitude_list[source - 1], longitude_list[target - 1]],
                 [latitude_list[source - 1], latitude_list[target - 1]], color='black', linestyle='-')

    # 显示图例，只显示一次
    plt.legend(loc='upper right')

    # 显示图形
    plt.show()
