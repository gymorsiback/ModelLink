class UserRequest:
    def __init__(self, user_id, lo, la, route, w1, w2):
        self.UserId = user_id
        self.Lo = lo        # 经度
        self.La = la        # 维度
        self.route = route  # 需要哪几个类型的模型
        self.w1 = w1        # 精度权重
        self.w2 = w2        # 速度权重

    def __str__(self):
        return f"UserRequest(UserId={self.UserId}, Lo={self.Lo}, La={self.La}, route={self.route}, w1={self.w1}, w2={self.w2})"


# 存储UserRequest实例的字典，以user_id为键
user_requests = {}

def create_user_requests_by_userID(userID):
    import pandas as pd
    # 读取CSV文件
    df = pd.read_csv("./data/user_data.csv")
    # 根据userID查找对应行
    user_row = df[df['UserId'] == userID].iloc[0]
    # 注意: 这里使用eval是为了将字符串转换成列表，实际操作中应当谨慎使用eval，或者寻找替代的安全方式
    route_as_list = eval(user_row['route']) if isinstance(user_row['route'], str) else user_row['route']
    # 创建UserRequest对象
    user_request = UserRequest(user_id=user_row['UserId'],
                               lo=user_row['Lo'],
                               la=user_row['La'],
                               route=route_as_list,
                               w1=user_row['w1'],
                               w2=user_row['w2'])
    return user_request


# def create_new_user_requests_by_para(w1, w2):
#     import random   # 用于生成随机经纬度
#     import csv
#     try:
#         with open("./data/user_data.csv", mode='r') as file:
#             reader = csv.DictReader(file)
#             max_user_id = max(int(row['UserId']) for row in reader)
#     except (FileNotFoundError, ValueError):
#         max_user_id = 0  # 如果文件不存在或为空，则从 0 开始

#     # 生成新的 UserId
#     new_user_id = max_user_id + 1

#     # 生成位于澳大利亚范围内的经纬度
#     lo = random.uniform(113.338953, 153.569469)  # 澳大利亚的经度范围
#     la = random.uniform(-43.634597, -10.668185)  # 澳大利亚的纬度范围
#     route = random.sample(range(1, 10), 2)  # 假设路线为随机选择的模型类型

#     # 创建 UserRequest 实例
#     request = UserRequest(new_user_id, lo, la, route, w1, w2)
#     return request

def create_new_user_requests_by_para(w1, w2, filepath='data/user_data.csv'):
    import csv
    requests = []
    try:
        with open(filepath, mode='r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                # 使用传入的 w1, w2 替换原有值
                new_request = UserRequest(
                    user_id=int(row['UserId']),
                    lo=float(row['Lo']),
                    la=float(row['La']),
                    route=eval(row['route']),
                    w1=w1,
                    w2=w2
                )
                requests.append(new_request)
    except FileNotFoundError:
        print(f"File {filepath} not found.")

    return requests





def create_user_requests_from_csv(csv_filename):  
    """从CSV文件中读取数据并创建UserRequest实例"""  
    with open(csv_filename, 'r') as csvfile:  
        # 跳过文件头  
        next(csvfile)  
        for line in csvfile:  
            # 分割每行数据  
            user_id, lo, la, server_performance = line.strip().split(',')  
            # 转换数据类型（如果需要）  
            user_id = int(user_id)  
            lo = float(lo)  
            la = float(la)  
            server_performance = float(server_performance)  
            # 创建UserRequest实例并添加到字典中  
            create_user_request(user_id, lo, la, None, None, server_performance)  
  
def create_user_request(user_id, lo, la, route=None, w1=None, w2=None):  
    """创建UserRequest实例并将其添加到字典中"""  
    # 注意：route, w1, w2 在这个CSV中并未使用，所以使用默认值None  
    user_request = UserRequest(user_id, lo, la, route if route is not None else server_performance)  
    user_requests[user_id] = user_request  
    return user_request  
  
# 使用函数从CSV文件中创建UserRequest实例  
# create_user_requests_from_csv('path_to_your_csv_file.csv')  # 替换为你的CSV文件路径  
  
# 打印所有UserRequest实例以验证  
# for user_id, user_request in user_requests.items():  
#     print(user_request)

'''
def create_user_request(user_id, lo, la, route, w1, w2):
    """创建UserRequest实例并将其添加到字典中"""
    user_request = UserRequest(user_id, lo, la, route, w1, w2)
    user_requests[user_id] = user_request
    return user_request
'''

def get_user_request(user_id):
    """根据user_id获取UserRequest实例"""
    return user_requests[user_id]


def release_user_request(user_id):
    """释放特定user_id对应的UserRequest实例"""
    if user_id in user_requests:
        del user_requests[user_id]
        print(f"UserRequest with user_id {user_id} has been released.")
    else:
        print(f"No UserRequest found with user_id {user_id}.")


