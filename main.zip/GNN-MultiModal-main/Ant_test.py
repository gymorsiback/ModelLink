import numpy as np

from GNN.GNN_init import node_embeddings
from dataPreprocess import *
from collections import defaultdict
import matplotlib.pyplot as plt
import copy
# # 初始化参数
# num_ants = 10  # 蚂蚁数量
# num_iterations = 10  # 迭代次数
# alpha = 1  # 信息素重要程度
# beta = 1  # 启发式信息重要程度
# rho = 0.1  # 信息素挥发率
# Q = 1  # 信息素强度
# total_nodes = len(node_class)  # 总节点数
# # lo = 144.95123  # 用户
# # la = 37.809081  # 用户
# # route_copy = [1, 2, 3]  # 用户传入
# # w1 = 0.6
# # w2 = 0.4
# c1 = 1
# c2 = 1
# c3 = 1
# w3 = 0.1

# 0.5,0.5,50,0.4,50,68,0.68,1.0

def test_Ant_final(lo, la, route, w1, w2, alpha=0.5, beta=0.5, Q=50, rho=0.4, num_ants=50):
    # 初始化参数
    # print("传入")
    route_copy = copy.deepcopy(route)
    # print("传入", route_copy)
    # num_ants = 10  # 蚂蚁数量
    num_iterations = 10  # 迭代次数
    # alpha = 1  # 信息素重要程度
    # beta = 1  # 启发式信息重要程度
    # rho = 0.1  # 信息素挥发率
    # Q = 100  # 信息素强度
    total_nodes = len(node_class)  # 总节点数
    c1 = 1
    c2 = 0.1
    c3 = 1
    adjmatrix = np.zeros((total_nodes, total_nodes), dtype=int)
    adjmatrix[0, :] = 1
    adjmatrix[:, 0] = 1
    # 遍历起点和终点对，更新邻接矩阵
    for start, end in zip(edge_row_1, edge_row_2):
        # 减1是因为数组索引从0开始，而节点编号从1开始
        start_index = start
        end_index = end
        adjmatrix[start_index, end_index] = 1
    # 打印邻接矩阵
    # print(adjmatrix)
    node_costs = np.zeros((total_nodes, total_nodes), dtype=float)
    for i in range(1, len(adjmatrix)):
        for j in range(1, len(adjmatrix)):
            if adjmatrix[i][j] != 0:
                # 计算Haversine距离
                node_costs[i][j] = c2 * haversine(locations[i-1][0], locations[i-1][1], locations[j-1][0], locations[j-1][1])
    # print(node_costs)
    StartorEnd = [node_id for node_id, class_id in node_class.items() if class_id == route_copy[0] or class_id == route_copy[len(route_copy)-1]]
    # print(StartorEnd)
    # 加入用户与这些节点的距离
    for j in StartorEnd:
        node_costs[0][j] = haversine(lo, la, locations[j - 1][0], locations[j - 1][1])
    # print(node_costs)
    for i in range(1, len(adjmatrix)):
        node_costs[i][0] = haversine(lo, la, locations[i - 1][0], locations[i - 1][1])
    # 加入模型和服务器评分
    for j in range(1, len(node_costs)):
        for i in range(0, len(node_costs)):
            node_costs[i][j] += w1*(c1/(Node_matrix[j-1][3]*Node_matrix[j-1][5])+node_costs[i][j])+w2*(c3/Node_matrix[j-1][4])
    # print(node_costs)
    # 加入GNN嵌入向量
    for i in range(1, len(adjmatrix)):
        for j in range(1, len(adjmatrix)):
            if adjmatrix[i][j] != 0:
                node_costs[i][j] += torch.norm(node_embeddings[i-1] - node_embeddings[j-1], p=2).item()
    np.fill_diagonal(node_costs, np.inf)  # 将对角线设置为无穷大，避免蚂蚁停留在同一个节点
    # print(node_costs)
    # 初始化信息素矩阵，所有边的信息素初始化为1
    pheromone_matrix = np.ones((total_nodes, total_nodes))
    # print(pheromone_matrix)
    # 给定顺序数组route_copy
    # 初始化启发式信息矩阵（这里使用代价的倒数作为启发式信息）
    heuristic_matrix = 1.0 / node_costs
    # heuristic_matrix = node_costs
    # print(heuristic_matrix)
    np.fill_diagonal(heuristic_matrix, 0)  # 对角线设置为0
    # 蚁群算法主循环
    best_path = None
    best_cost = np.inf
    route_copy.insert(0,0)
    route_copy.append(0)
    # print(route_copy)
    for iteration in range(num_iterations):
        # print("iteration")
        all_paths = []
        all_costs = []

        # 每只蚂蚁构建路径
        for ant in range(num_ants):
            current_node = 0  # 起始节点
            # current_class = route_copy[0]
            path = [current_node]
            cost = 0

            for next_class in route_copy[1:]:
                # 获取属于下一个类别的所有节点编号
                possible_next_nodes = [node_id for node_id, class_id in node_class.items() if class_id == next_class]
                # print(possible_next_nodes)
                probabilities = (pheromone_matrix[current_node, possible_next_nodes] ** alpha) * (
                            heuristic_matrix[current_node, possible_next_nodes] ** beta)
                probabilities /= probabilities.sum()
                # print(probabilities)
                # 选择下一个节点
                next_node = np.random.choice(possible_next_nodes, p=probabilities)
                path.append(next_node)
                cost += node_costs[current_node, next_node]  # 累加代价
                current_node = next_node
                # current_class = next_class

            # 添加回到起始节点的步骤（如果需要的话）
            if path[-1] != 0:
                path.append(0)
                cost += node_costs[path[-2], 0]

            all_paths.append(path)
            # print(path)
            all_costs.append(cost)

            # 更新最优路径和最优代价
            if cost < best_cost:
                best_cost = cost
                best_path = path
                # print(path)

        # 信息素挥发
        pheromone_matrix *= (1 - rho)

        # 如果找到了更优的路径，进行信息素增强
        if best_path is not None:
            for i in range(len(best_path) - 1):
                pheromone_matrix[best_path[i], best_path[i + 1]] += Q / best_cost

    # 输出最优路径和最优代价
    # print("Ant Path:", best_path)
    # print("Best Cost:", best_cost)
    return best_path
    test_drawpath(best_path, lo, la)


def test_drawpath(best_path, lo, la):
    longitude, latitude = zip(*locations)
    category_coordinates = defaultdict(list)
    for lon, lat, category in zip(longitude, latitude, Y):
        category_coordinates[category].append((lon, lat))
    # 绘制散点图
    plt.figure(figsize=(10, 8))

    # 遍历类别字典，绘制相同类别的坐标使用相同颜色
    for category, coordinates in category_coordinates.items():
        color = plt.cm.jet(category / max(Y))  # 使用viridis颜色映射
        plt.scatter(*zip(*coordinates), color=color, s=50, label=f'Category {category}')

    # 添加标签和标题
    plt.xlabel('Longitude')
    plt.ylabel('Latitude')
    plt.title('Scatter Plot of Coordinates')

    # 绘制用户点
    plt.scatter(lo, la, color='purple', s=100, label='User Coordinate')

    # 将元组转换为列表
    longitude_list = list(longitude)
    # 将用户添加到列表开头
    longitude_list.insert(0, lo)
    # 同理
    latitude_list = list(latitude)
    latitude_list.insert(0, la)

    for i in range(len(best_path) - 1):
        source, target = best_path[i], best_path[i + 1]
        plt.plot([longitude_list[source], longitude_list[target]],
                 [latitude_list[source], latitude_list[target]], color='black', linestyle='-')
    # 显示图例，只显示一次
    plt.legend(loc='upper right')

    # 显示图形
    plt.show()

