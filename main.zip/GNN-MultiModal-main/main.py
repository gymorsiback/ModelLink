# 转换边信息和成本
from utils import *
from PSO_GNN import *
from userRequest import *
from dataPreprocess import *
from A_star import *
import argparse
from Ant_GNN import *
# from GA_GNN import *
from BFS import *   
from GNN.GNN_init import node_embeddings
# request1 = create_user_requests_by_userID(1)
# # print(request1)
# A_star_final(request1.Lo,request1.La,request1.route,float(request1.w1),float(request1.w2))

def main(user_id, algorithm):
    request = create_user_requests_by_userID(user_id)
    print(request)  # 打印UserRequest对象信息，可选
    # A_star_final(request.Lo, request.La, request.route, float(request.w1), float(request.w2))
    # test_Ant_final(request.Lo, request.La, request.route, float(request.w1), float(request.w2))
    # PSO(request.Lo, request.La, request.route, float(request.w1), float(request.w2))
    # GA(request.Lo, request.La, request.route, float(request.w1), float(request.w2))
    args = {
        'lo': request.Lo,
        'la': request.La,
        'route': request.route,
        'w1': float(request.w1),
        'w2': float(request.w2),
        'node_embeddings': node_embeddings
    }

    # 根据不同算法调用相应的函数
    if algorithm == 'a_star':
        A_star_final(**args)
    elif algorithm == 'ant':
        test_Ant_final(**args)
    elif algorithm == 'pso':
        PSO(**args)
    elif algorithm == 'ga':
        GA(**args)
    elif algorithm == 'bfs':
        BFS(**args)
    else:
        print("Unknown algorithm. Please specify 'a_star', 'ant', 'pso', or 'ga'.")
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Execute UserRequest with A* algorithm.")
    # parser.add_argument('user_id', type=int, help="UserID for which to execute the UserRequest")
    parser.add_argument('-u', '--user_id', type=int, required=True, help="UserID for which to execute the UserRequest")
    parser.add_argument('-a', '--algorithm', type=str, required=True, choices=['a_star', 'ant', 'pso', 'ga', 'bfs'],
                        help="Algorithm to use for executing the UserRequest")

    args = parser.parse_args()
    main(args.user_id, args.algorithm)


