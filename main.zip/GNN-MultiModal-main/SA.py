#!/usr/bin/python
# -*-coding: UTF-8 -*-
import os
import sys
from random import choice, shuffle, sample, uniform
from GNN import node_embeddings
from dataPreprocess import *
import numpy as np
sys.path.append(r'/home/python')

total_nodes = len(node_class)  # 总节点数
lo = 144.95123  # 用户
la = 37.809081  # 用户
route = [1, 2, 3]  # 用户传入
w1 = 0.6
w2 = 0.4
w3 = 0.1
c1 = 1
c2 = 1
c3 = 1
w3 = 0.1

adjmatrix = np.zeros((total_nodes, total_nodes), dtype=int)
adjmatrix[0, :] = 1
adjmatrix[:, 0] = 1
# 遍历起点和终点对，更新邻接矩阵
for start, end in zip(edge_row_1, edge_row_2):
    # 减1是因为数组索引从0开始，而节点编号从1开始
    start_index = start
    end_index = end
    adjmatrix[start_index, end_index] = 1
# 打印邻接矩阵
# print(adjmatrix)
node_costs = np.zeros((total_nodes, total_nodes), dtype=float)
for i in range(1, len(adjmatrix)):
    for j in range(1, len(adjmatrix)):
        if adjmatrix[i][j] != 0:
            # 计算Haversine距离
            node_costs[i][j] = w3 * haversine(locations[i-1][0], locations[i-1][1], locations[j-1][0], locations[j-1][1])
# print(node_costs)
StartorEnd = [node_id for node_id, class_id in node_class.items() if class_id == route[0] or class_id == route[len(route)-1]]
# print(StartorEnd)
# 加入用户与这些节点的距离
for j in StartorEnd:
    node_costs[0][j] = haversine(lo, la, locations[j - 1][0], locations[j - 1][1])
# print(node_costs)
for i in range(1, len(adjmatrix)):
    node_costs[i][0] = haversine(lo, la, locations[i - 1][0], locations[i - 1][1])
# 加入模型和服务器评分
for j in range(1, len(node_costs)):
    for i in range(0, len(node_costs)):
        node_costs[i][j] += w1*(c1/Node_matrix[j-1][3] + c2/Node_matrix[j-1][5])+w2*(c3/Node_matrix[j-1][4])
# print(node_costs)
# 加入GNN嵌入向量
for i in range(1, len(adjmatrix)):
    for j in range(1, len(adjmatrix)):
        if adjmatrix[i][j] != 0:
            node_costs[i][j] += torch.norm(node_embeddings[i-1] - node_embeddings[j-1], p=2).item()




### 参数：最小路径的最后一个节点和邻域
def valSimulateAnnealSum(count, nextnodeList,curnode, selectedList, t):
    # print(nextnodeList)
    if nextnodeList == None or len(nextnodeList) < 1:
        print("empty")
        return 0

    maxcost = node_costs[curnode][selectedList[count+1]]+node_costs[selectedList[count+1]][selectedList[count+2]]

    for node in nextnodeList:
        # print "curnode : ",curnode ," node: " ,node ," mincost : ",mincost

        t *= 0.98  ## 退火因子
        if node_costs[curnode][node]+node_costs[node][count+2] < maxcost:
            maxcost = node_costs[curnode][node]+node_costs[node][count+2]
            selectedList[count+1] = node
        ## 以一定的概率接受较差的解
        else:
            r = uniform(0, 1)
            if node_costs[curnode][node]+node_costs[node][count+2] > maxcost and t > t_min and math.exp((node_costs[curnode][node]+node_costs[node][count+2] - maxcost) / t) > r:
                #              print " t = " ,t , "maxcost = ", maxcost , " arr = " ,arr[curnode][node],   "  exp = ",math.exp((arr[curnode][node] - maxcost)/t)  ,  " r = ",r , "t_min = " ,t_min
                selectedList[count+1] = node
                maxcost = node_costs[curnode][node]+node_costs[node][count+2]
                # print(retnode)
                return selectedList, t

    return selectedList, t


indexList = [i for i in range(total_nodes)]  ### 原始的节点序列
selectedList = []  ## 选择好的元素

### 具体思想是： 从剩余的元素中随机选择十分之一的元素，作为邻域。然后从邻域中选择一个元素作为已经构建好的最小路径的下一个节点，使得该路径
mincost = sys.maxsize  ###最小的花费
advance = 0
target = []
length = []
selectedList.append(0)
for i in range(0, len(route)):
    if route[i] == 1:
        num = 4
        advance = 1
        sub_index = indexList[advance:advance + num]
        target += sub_index
        length.append(num)
        selectedList.append(choice(sub_index))
    elif route[i] == 2:
        num = 3
        advance = 5
        sub_index = indexList[advance:advance + num]
        target += sub_index
        length.append(num)
        selectedList.append(choice(sub_index))
    elif route[i] == 3:
        num = 4
        advance = 8
        sub_index = indexList[advance:advance + num]
        target += sub_index
        length.append(num)
        selectedList.append(choice(sub_index))
    elif route[i] == 4:
        num = 3
        advance = 12
        sub_index = indexList[advance:advance + num]
        target += sub_index
        length.append(num)
        selectedList.append(choice(sub_index))
    elif route[i] == 5:
        num = 1
        advance = 15
        sub_index = indexList[advance:advance + num]
        target += sub_index
        length.append(num)
        selectedList.append(choice(sub_index))
    elif route[i] == 6:
        num = 1
        advance = 16
        sub_index = indexList[advance:advance + num]
        target += sub_index
        length.append(num)
        selectedList.append(choice(sub_index))
selectedList.append(0)
print(selectedList)
print(length)
print(target)

num = 0

count = 0  ### 计数器
t = 100  ## 初始温度`
t_min = 50  ## 最小温度

while count < len(route):
    temp = num
    num += length[count]
    curnode = selectedList[count]
    nextCodes = target[temp:num]
    print(nextCodes)
    # print "nextnodeList:" ,nextnodeList
    selectedList, t = valSimulateAnnealSum(count, nextCodes, curnode, selectedList, t)  ### 对待选的序列路径求和
    count += 1

print("最合适的路径为：", selectedList)
#### 画图 #####
# plt.figure(1)
x = []
y = []
for i in selectedList:
    x.append(list[i])
    y.append(list[i])
# plt.plot(x,y)
# plt.show()
print
"x: ", x
print
"y: ", y
