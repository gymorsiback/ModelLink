from utils import *
from PSO_GNN import *
from greedy import *
# from PSO_GNN import *
from userRequest import *
from dataPreprocess import *
from A_star import *
import argparse
from Ant_GNN import *
from GA_GNN import *
from BFS import *
import matplotlib.pyplot as plt
import timeit
from collections import Counter


# 准确率测试和时间测试的通用算法调用函数
def run_algorithm(algorithm, request, node_embeddings):
    algorithms = {
        'a_star': A_star_final,
        'ant': test_Ant_final,
        'pso': PSO,
        'ga': GA,
        'bfs': BFS,
        'greedy': Greedy
    }

    function = algorithms.get(algorithm)
    if function:
        return function(request.Lo, request.La, request.route, float(request.w1), float(request.w2), node_embeddings)
    else:
        print(f"Unknown algorithm: {algorithm}")
        return None


# 准确率测试函数
def test_accuracy(user_id, algorithm, node_embeddings):
    request = create_user_requests_by_userID(user_id)
    path1 = BFS(request.Lo, request.La, request.route, float(request.w1), float(request.w2),node_embeddings)
    path2 = run_algorithm(algorithm, request, node_embeddings)
    path1.pop(0)
    path2.pop(0)
    path1.pop()
    path2.pop()
    return 1 if path1 == path2 else 0


# 鲁棒性测试函数，运行20次取平均
# 在 test_robustness 函数中，修改 results 列表的处理方式
def test_robustness(algorithm, node_embeddings, user_id=1, repetitions=20) :
    request = create_user_requests_by_userID(user_id)
    results = []

    for _ in range(repetitions):
        result = run_algorithm(algorithm, request, node_embeddings)
        results.append(result)

    # 将列表中的列表转换为元组，使其可哈希
    hashable_results = [tuple(r) if isinstance(r, list) else r for r in results]

    # 然后计算最常见结果的频率
    most_common_result, count = Counter(hashable_results).most_common(1)[0]
    return count / repetitions


# 主测试函数
def test(node_embeddings):
    user_ids = range(1, 101)
    # algorithms = ['bfs', 'a_star', 'pso']
    # algorithms = ['ant', 'pso', 'a_star']
    algorithms = ['greedy']
    # TODO: 为了测试方便，暂时只测试 ant 算法
    accuracy_counts = {alg: 0 for alg in algorithms}
    total_times = {alg: 0 for alg in algorithms}
    robustness_rates = {alg: 0 for alg in algorithms}

    for user_id in user_ids:
        request = create_user_requests_by_userID(user_id)
        for algorithm in algorithms:
            # 准确率测试
            accuracy_counts[algorithm] += test_accuracy(user_id, algorithm, node_embeddings)

            # 时间测试，十次取平均
            execution_times = timeit.repeat(
                lambda: run_algorithm(algorithm, request, node_embeddings),
                repeat=5,  # 重复次数
                number=1  # 每次重复执行的次数
            )
            average_time = sum(execution_times) / len(execution_times)
            total_times[algorithm] += average_time

            # 仅对 user_id 为 1 的情况测试鲁棒性
            if user_id == 1:
                robustness_rates[algorithm] = test_robustness(algorithm, node_embeddings)


    # return accuracy_counts, total_times, robustness_rates
    accuracy_rates = {alg: accuracy_counts[alg] / len(user_ids) for alg in algorithms}
    average_times = {alg: total_times[alg] / len(user_ids) for alg in algorithms}
    return accuracy_rates, average_times, robustness_rates

    # 计算并绘制准确率图
    # accuracy_rates = {alg: accuracy_counts[alg] / len(user_ids) for alg in algorithms}
    # plt.figure(figsize=(10, 6))
    # plt.plot(['BFS'] + list(accuracy_rates.keys()), [1.0] + list(accuracy_rates.values()), marker='o', linestyle='-')
    # plt.title('Algorithm Accuracy Comparison')
    # plt.xlabel('Algorithm')
    # plt.ylabel('Accuracy Rate')
    # plt.grid(True)
    # plt.show()

    # # 计算并绘制执行时间图
    # average_times = {alg: total_times[alg] / len(user_ids) for alg in algorithms}
    # plt.figure(figsize=(10, 6))
    # plt.plot(average_times.keys(), average_times.values(), marker='o', linestyle='-')
    # plt.title('Average Execution Time for Algorithms')
    # plt.xlabel('Algorithm')
    # plt.ylabel('Average Time (seconds)')
    # plt.grid(True)
    # plt.show()

    # # 绘制鲁棒性图
    # plt.figure(figsize=(10, 6))
    # plt.plot(robustness_rates.keys(), robustness_rates.values(), marker='o', linestyle='-')
    # plt.title('Robustness of Algorithms')
    # plt.xlabel('Algorithm')
    # plt.ylabel('Robustness Rate')
    # plt.grid(True)
    # plt.show()


