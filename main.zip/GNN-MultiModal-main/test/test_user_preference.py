import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from GNN.GNN_best import node_embeddings
from dataPreprocess import *
from test.test_module_for_User import *

import pandas as pd


def test_user(w1, w2, node_embeddings):
    # user_ids = range(low, high)
    # algorithms = ['bfs', 'a_star', 'pso']
    # algorithms = ['ant', 'pso', 'a_star']
    algorithms = ['ant']
    times = 100
    # TODO: 为了测试方便，暂时只测试 ant 算法
    accuracy_counts = {alg: 0 for alg in algorithms}
    total_times = {alg: 0 for alg in algorithms}
    robustness_rates = {alg: 0 for alg in algorithms}

    requests = create_new_user_requests_by_para(w1, w2)
    for request in requests:
        
        for algorithm in algorithms:
            # 准确率测试
            accuracy_counts[algorithm] += test_accuracy(request, algorithm, node_embeddings)

            # 时间测试，十次取平均
            execution_times = timeit.repeat(
                lambda: run_algorithm(algorithm, request, node_embeddings),
                repeat=5,  # 重复次数
                number=1  # 每次重复执行的次数
            )
            average_time = sum(execution_times) / len(execution_times)
            total_times[algorithm] += average_time

            # 仅对 i 为 1 的情况测试鲁棒性
            if request.UserId == 1:
                robustness_rates[algorithm] = test_robustness(algorithm, node_embeddings, request)


    # return accuracy_counts, total_times, robustness_rates
    accuracy_rates = {alg: accuracy_counts[alg] / len(requests) for alg in algorithms}
    average_times = {alg: total_times[alg] / len(requests) for alg in algorithms}
    return accuracy_rates, average_times, robustness_rates



def test_user_preference():
    # 测试参数设置
    data = Data(x=torch.tensor(Node_matrix, dtype=torch.float), 
            edge_index=torch.tensor(edge, dtype=torch.long),
            edge_attr=torch.tensor(edge_features, dtype=torch.float))
    data.edge_index = data.edge_index - 1

    results = []

    # 测试不同的参数
    step = 0.1  # 可以调整为所需的粒度
    w1_values = [round(i, 2) for i in np.arange(0, 1 + step, step)]  # 确保包括 1
    w2_values = [round(1 - w1, 2) for w1 in w1_values]

    for w1, w2 in zip(w1_values, w2_values):
        print(f"w1: {w1}, w2: {w2}") 

        accuracy_rates, average_times, robustness_rates = test_user(w1, w2, node_embeddings) 

        for algorithm in accuracy_rates.keys():
            result = {
                'user_prefer_w1': w1,
                'user_prefer_w2': w2,
                'algorithm': algorithm,
                'accuracy_rate': accuracy_rates[algorithm],
                'average_time': average_times[algorithm],
                'robustness_rate': robustness_rates.get(algorithm, None) # 使用get以防某些算法没有鲁棒性评分
                # 'embeddings': node_embeddings.tolist()  # 将tensor转换为list以便存储
            }
            results.append(result)
        print("-------------------")

    df = pd.DataFrame(results)
    df.to_csv('result/results_user_perference.csv', index=False)
    



test_user_preference()