# 横坐标 Epoch Loss 优化器 激活函数 输出向量维度 GNN结构
# 纵坐标 现有指标(准确率, 鲁棒性, 执行时间)
# import sys
# # 添加上级目录到系统路径中
# sys.path.append('..')

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from GNN.GNN_improve import *
from dataPreprocess import *
from test_module_for_GNN import *

import pandas as pd



# 测试参数设置
# TODO: 请根据需要调整参数
epochs_list = [100]
# epochs_list = [100,200,300]
# optimizers = {
#     #  'SGD': {'class': optim.SGD, 'params': {'lr': 0.01}},
#      'Adam': {'class': optim.Adam, 'params': {'lr': 0.001}},
#     #  'RMSprop': {'class': optim.RMSprop, 'params': {'lr': 0.01}},
#  }
# optimizers = {
#     'Adam': {'class': optim.Adam, 'params': {'lr': 0.001}},
#     'RMSprop': {'class': optim.RMSprop, 'params': {'lr': 0.01}},
#     'Adadelta': {'class': optim.Adadelta, 'params': {'lr': 0.01}},
#     'SGD': {'class': optim.SGD, 'params': {'lr': 0.01}},
#     'Adagrad': {'class': optim.Adagrad, 'params': {'lr': 0.01}},
#     'Adamax': {'class': optim.Adamax, 'params': {'lr': 0.002}},
#     'ASGD': {'class': optim.ASGD, 'params': {'lr': 0.01}},
#     'Rprop': {'class': optim.Rprop, 'params': {'lr': 0.01}},
#     # 'SparseAdam': {'class': optim.SparseAdam, 'params': {'lr': 0.001}},
#     'AdamW': {'class': optim.AdamW, 'params': {'lr': 0.001}},
#     'SGD_momentum': {'class': optim.SGD, 'params': {'lr': 0.01, 'momentum': 0.9}},
#     'Adam_momentum': {'class': optim.Adam, 'params': {'lr': 0.001, 'betas': (0.9, 0.999)}},
# }
optimizers = {
   'Adam': {'class': optim.Adam, 'params': {'lr': 0.001}},
}
# loss_functions = [F.mse_loss, F.l1_loss, F.smooth_l1_loss, ]
# loss_functions = [F.l1_loss, F.smooth_l1_loss, F.binary_cross_entropy_with_logits, F.hinge_embedding_loss, F.mse_loss,  F.cross_entropy, F.kl_div]
loss_functions = [F.smooth_l1_loss]
# loss_functions = [F.mse_loss]
# activation_functions = [F.hardtanh, F.hardsigmoid, F.hardshrink, F.softsign, F.softshrink, F.softplus, F.elu, F.tanh, F.sigmoid, F.relu, F.leaky_relu, F.selu]
activation_functions = [F.selu]
# output_features_list = [8, 16, 32]
output_features_list = [8]

def test_gnn_parameters(epochs_list, optimizers, loss_functions, activation_functions, output_features_list):
    # 初始化数据
    
    data = Data(x=torch.tensor(Node_matrix, dtype=torch.float), 
            edge_index=torch.tensor(edge, dtype=torch.long),
            edge_attr=torch.tensor(edge_features, dtype=torch.float))
    data.edge_index = data.edge_index - 1

    results = []


    # 测试不同的参数
    for epochs in epochs_list:
        for output_features in output_features_list:
            for activation_function in activation_functions:
                model = GCNModel(Node_matrix.shape[1], output_features, activation_function)
                
                for optimizer_name, optimizer_parameters in optimizers.items():
                    optimizer = optimizer_parameters['class'](model.parameters(), **optimizer_parameters['params'])
                    
                    for loss_function in loss_functions:
                        print(f"Testing with epochs={epochs}, output_features={output_features}, "
                              f"activation_function={activation_function.__name__}, "
                              f"optimizer={optimizer_name}, loss_function={loss_function.__name__}")

                        # 训练模型
                        train_gnn(model, data, epochs, optimizer, loss_function)

                        # 评估模型
                        embeddings = evaluate_gnn(model, data)

                        accuracy_rates, average_times, robustness_rates = test(embeddings)
                        
                        
                        for algorithm in accuracy_rates.keys():
                            result = {
                                'epochs': epochs,
                                'output_features': output_features,
                                'activation_function': activation_function.__name__,
                                'optimizer': optimizer_name,
                                'loss_function': loss_function.__name__,
                                'algorithm': algorithm,
                                'accuracy_rate': accuracy_rates[algorithm],
                                'average_time': average_times[algorithm],
                                'robustness_rate': robustness_rates.get(algorithm, None),  # 使用get以防某些算法没有鲁棒性评分
                                'embeddings': embeddings.tolist()  # 将tensor转换为list以便存储
                            }
                            results.append(result)
                        print("-------------------")


    # df = pd.DataFrame(results)
    # df.to_csv('activation_pso.csv', index=False)


# 测试不同的参数配置
test_gnn_parameters(epochs_list, optimizers, loss_functions, activation_functions, output_features_list)
