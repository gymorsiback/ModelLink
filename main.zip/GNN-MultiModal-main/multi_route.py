# 转换边信息和成本
from utils import *
from PSO_GNN import *
from greedy_new import *
from userRequest import *
from dataPreprocess import *
from A_star import *
import argparse
from Ant_GNN import *
# from GA_GNN import *
from BFS import *
from GNN.GNN_init import node_embeddings
# request1 = create_user_requests_by_userID(1)
# # print(request1)
# A_star_final(request1.Lo,request1.La,request1.route,float(request1.w1),float(request1.w2))

def main(user_id, algorithm):
    request = create_user_requests_by_userID(user_id)
    print(request)  # 打印UserRequest对象信息，可选

    # 使用 linspace 函数从 request.w1 到 request.w2 均匀生成5个点
    points = np.linspace(request.w1, request.w2, 10)
    # 打印生成的点
    print(points)

    # 假设这些函数返回一个数组，我们创建一个空列表来存储结果
    results = []

    # 循环
    for point in points:
        # 更新 w1 和 w2 的值
        w1 = point * 10
        w2 = (1 - point) * 10
        args = {
            'lo': request.Lo,
            'la': request.La,
            'route': request.route,
            'w1': float(w1),
            'w2': float(w2),
            'node_embeddings': node_embeddings
        }

        # 根据不同算法调用相应的函数，并将结果存储到 results 列表中
        if algorithm == 'a_star':
            result = A_star_final(**args)
        elif algorithm == 'ant':
            result = test_Ant_final(**args)
        elif algorithm == 'pso':
            result = PSO(**args)
        elif algorithm == 'greedy':
            result = Greedy(**args)
        elif algorithm == 'bfs':
            result = BFS(**args)
        else:
            print("Unknown algorithm. Please specify 'a_star', 'ant', 'pso', or 'greedy'.")
            return

        # 去头去尾并存储结果
        if result:
            # result.pop(0)
            # result.pop()
            results.append(result)

    # 打印不同的结果
    unique_results = set(tuple(result) for result in results)
    print("路径集:")
    for result in unique_results:
        print(result)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Execute UserRequest with A* algorithm.")
    # parser.add_argument('user_id', type=int, help="UserID for which to execute the UserRequest")
    parser.add_argument('-u', '--user_id', type=int, required=True, help="UserID for which to execute the UserRequest")
    parser.add_argument('-a', '--algorithm', type=str, required=True, choices=['a_star', 'ant', 'pso', 'greedy', 'bfs'],
                        help="Algorithm to use for executing the UserRequest")

    args = parser.parse_args()
    main(args.user_id, args.algorithm)


