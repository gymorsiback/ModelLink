# 最大最小归一化函数
def minmax_normalize(data):
    normalized = [[0, 0] for _ in range(len(data))]

    # 如果只有一行,不做归一化
    if len(data) == 1:
        normalized[0][0] = data[0][0]
        normalized[0][1] = 1
        return normalized

    col = [row[1] for row in data]
    min_val = min(col)
    max_val = max(col)

    for i, row in enumerate(data):
        normalized[i][0] = row[0]
        normalized[i][1] = (row[1] - min_val) / (max_val - min_val) + 1

    return normalized


# 
def create_adj_list(edge_index, edge_attr):
    adj_list = {}
    for i, (src, dest) in enumerate(edge_index.t()):
        weight = edge_attr[i].item()
        if src.item() not in adj_list:
            adj_list[src.item()] = []
        adj_list[src.item()].append((dest.item(), weight))
    return adj_list



# 根据经纬度计算地球上两点距离的半正矢公式（haversine 公式）
def haversine(lon1, lat1, lon2, lat2):
    import math

    # 将经度变成弧度
    lon1, lat1, lon2, lat2 = map(math.radians, [lon1, lat1, lon2, lat2])

    # haversine公式
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
    c = 2 * math.asin(math.sqrt(a))

    # 地球平均半径,单位为公里
    r = 6371

    return c * r


def create_graph_and_costs(edge, edge_features_flat): 
    from collections import defaultdict
    graph = defaultdict(list)
    costs = {}
    for start, end, cost in zip(edge[0], edge[1], edge_features_flat):
        graph[start].append(end)
        costs[(start, end)] = cost
    return graph, costs

dw = 0.05