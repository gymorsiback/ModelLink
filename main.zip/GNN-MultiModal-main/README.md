
`edge`: 2*N matrix

`edge_features`: 1*N matrix

`edge_features_flat`: 1*N matrix

