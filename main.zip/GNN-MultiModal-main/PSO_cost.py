import numpy as np
import matplotlib.pyplot as plt
# from GNN.GNN_init import node_embeddings
from utils import *
from dataPreprocess import *
from collections import defaultdict
import time



class Particle:
    def __init__(self, num_cities, route):
        self.position = [0] * num_cities
        self.position[0] = route[0][0]
        self.position[num_cities-1] = route[num_cities-1][0]
        for t in range(1,num_cities):
            self.position[t] = np.random.choice(route[t])  # 随机初始化粒子路径
        # self.point = self.position[1]         # 最新位置
        # self.index = 1                        # 初始索引
        # self.maxindex = 1                     # end索引
        # 路径上每个点的速度
        self.velocity = np.zeros(num_cities)  # 初始化粒子速度
        self.best_position = self.position.copy()  # 初始化粒子的最佳路径
        # self.bestpoint = self.point
        self.best_score = float('inf')  # 初始化粒子成本

    def update_velocity(self, gbest_position, w, c1, c2):
        # 根据PSO算法更新速度
        r1 = np.random.rand(len(self.position))
        r2 = np.random.rand(len(self.position))
        # 认知速度，反映了粒子向自身历史最佳位置移动的趋势
        cognitive_velocity = c1 * r1 * (np.array(self.best_position) - np.array(self.position))
        # 社会速度，反映了粒子向全局最佳位置移动的趋势
        social_velocity = c2 * r2 * (np.array(gbest_position) - np.array(self.position))
        self.velocity = w * self.velocity + cognitive_velocity + social_velocity

    def update_position(self,route):
        # 根据速度和当前位置更新粒子路径
        for t in range(len(route)):
            i = int((self.position[t] + self.velocity[t]) % len(route[t]))
            self.position[t] = route[t][i]


def heuristic(start, end, node_embeddings):
    # 简化版的启发式函数,结合GNN计算当前路径的h成本
    return torch.norm(node_embeddings[start - 1] - node_embeddings[end - 1], p=2).item()


def fitness(path, costs, node_embeddings):
    """
    粒子群优化算法的目标函数，用于评估粒子位置的适应度。
    计算给定路径的总成本。
    path: 节点索引的序列，表示从起点到终点的路径。
    start_node: 起点节点的索引。
    end_node: 终点节点的索引。
    costs: 一个字典，包含节点对之间的g成本。
    """
    total_cost = 0
    for i in range(len(path) - 1):
        current_node = path[i]
        next_node = path[i + 1]
        total_cost += (costs.get((current_node, next_node), float('inf')) + dw * heuristic(current_node, next_node, node_embeddings))
        # print(total_cost)
    return total_cost


# 粒子群优化算法
# def PSO(lo,la,route,w1,w2,edge=edge,edge_features=edge_features,locations=locations,model_performence=model_performence):
# test:
def PSO(lo, la, route, w1, w2, node_embeddings, iterr=30, w=0.9, s1=1.5, s2=1.5, population_size=200, edge=edge, edge_features=edge_features, locations=locations,
            model_performence=model_performence):
    # 开始计时
    start_time = time.perf_counter()
    import copy
    edge_copy = copy.deepcopy(edge)
    edge_features_copy = copy.deepcopy(edge_features)
    locations_copy = copy.deepcopy(locations)
    model_performence_copy = copy.deepcopy(model_performence)
    # 将列表解析成经度和纬度的两个列表
    longitude, latitude = zip(*locations_copy)

    # 增加起点和终点（用户）
    route.insert(0, len(locations_copy) + 1)
    route.append(len(locations_copy) + 1)

    # 计算用户到locations中所有坐标的距离
    distance = [haversine(lo, la, lon, lat) for lon, lat in zip(longitude, latitude)]
    edge_copy = edge_copy.tolist()
    edge_features_copy = edge_features_copy.tolist()

    # 将用户到所有其他节点的边添加到 edge 中
    for i in range(len(locations_copy)):
        # 可去
        edge_copy[0].append(len(locations_copy) + 1)  # 用户点索引
        edge_copy[1].append(i + 1)
        # 可回
        edge_copy[0].append(i + 1)
        edge_copy[1].append(len(locations_copy) + 1)
    # 复制每个元素并放在原元素的后面
    distance_copy = np.repeat(distance, 2)

    # 将相应的距离添加到 edge_features 中
    edge_features_flat = [item for sublist in edge_features_copy for item in sublist]
    edge_features_flat.extend(distance_copy)
    node_efficiency = []

    # 权重，根据测试自己调整
    c1 = 1
    c2 = 0.1
    c3 = 1
    # model_performence
    for i in range(len(model_efficiency)):
        node_efficiency.append(c1 / (server_performence[i] * model_efficiency[i]))  # (c1 / server_performence[i]) + (c2 / model_efficiency[i])
    node_efficiency = [float(value) for value in node_efficiency]
    second_elements = [sub_array[1] for sub_array in model_performence_copy]  # second_elements是model_performence中元素的第二个元素
    for i in range(len(edge_copy[1])):
        if edge_copy[1][i] == len(locations_copy) + 1:
            edge_features_flat[i] += 0
        else:
            edge_features_flat[i] = w1 * (node_efficiency[edge_copy[1][i] - 1] + c2 * edge_features_flat[i]) + w2 * (
                        c3 / second_elements[edge_copy[1][i] - 1])

    Y_copy = copy.deepcopy(Y)
    Y_copy.append(len(locations_copy) + 1)
    route_pro = []

    for r in route:
        indices = [i + 1 for i, y in enumerate(Y_copy) if y == r]
        route_pro.append(indices)

    locations_copy.append([lo, la])
    graph, costs = create_graph_and_costs(edge_copy, edge_features_flat)

    '''
    # Actual
    iter = 60    # 最大迭代次数
    w = 0.8      # 惯性权重
    s1 = 0.5     # 个体学习因子
    s2 = 0.3     # 群体学习因子
    population_size = 50  # 粒子群数。简单问题一般取20~40，较难或特定类别的问题可以取100~200
    '''
    leng = len(route_pro)

    # 初始化粒子群
    swarm = [Particle(leng,route_pro) for _ in range(population_size)]

    # 初始化全局最优解
    gbest_score = float('inf')
    gbest_position = route_pro[0][0]
    # gbestpoint = 0

    cost = []
    times = []

    # PSO主循环
    for t in range(iterr):
        c = 0
        for particle in swarm:
            # 计算当前位置的适应度
            score = fitness(particle.position,costs, node_embeddings)
            c += score

            # 更新粒子个体最优解
            if score < particle.best_score:
                particle.best_score = score
                particle.best_position = particle.position.copy()
                # particle.bestpoint = particle.point

            # 更新全局最优解
            if score < gbest_score:
                gbest_score = score
                gbest_position = particle.best_position.copy()
                # gbestpoint = particle.point

        # 更新粒子速度和位置
        for particle in swarm:
            particle.update_velocity(gbest_position, w, s1, s2)
            particle.update_position(route_pro)
        # 记录当前时间
        current_time = time.perf_counter()

        # 计算从程序开始到当前迭代的经过时间
        elapsed_time = current_time - start_time

        cost.append(gbest_score)
        times.append(elapsed_time)
        # print(elapsed_time)

    # 返回全局最优解的路径
    # print(f"PSO Path: {gbest_position}")
    # print(gbest_score)
    route.pop(0)
    route.pop()
    return cost, times
    # drawpath(gbest_position,min_1,min_2)



    # 绘制结果散点图
def drawpath(best_path, lo, la):
    longitude, latitude = zip(*locations)
    category_coordinates = defaultdict(list)
    for lon, lat, category in zip(longitude, latitude, Y):
        category_coordinates[category].append((lon, lat))
    # 绘制散点图
    plt.figure(figsize=(10, 8))

    # 遍历类别字典，绘制相同类别的坐标使用相同颜色
    for category, coordinates in category_coordinates.items():
        color = plt.cm.jet(category / max(Y))  # 使用viridis颜色映射
        plt.scatter(*zip(*coordinates), color=color, s=50, label=f'Category {category}')

    # 添加标签和标题
    plt.xlabel('Longitude')
    plt.ylabel('Latitude')
    plt.title('Scatter Plot of Coordinates')

    # 绘制用户点
    plt.scatter(lo, la, color='purple', s=100, label='User Coordinate')

    # 将元组转换为列表
    longitude_list = list(longitude)
    # 将用户添加到列表开头
    longitude_list.insert(0, lo)
    # 同理
    latitude_list = list(latitude)
    latitude_list.insert(0, la)

    for i in range(len(best_path) - 1):
        source, target = best_path[i], best_path[i + 1]
        plt.plot([longitude_list[source], longitude_list[target]],
                 [latitude_list[source], latitude_list[target]], color='black', linestyle='-')
    # 显示图例，只显示一次
    plt.legend(loc='upper right')

    # 显示图形
    plt.show()

