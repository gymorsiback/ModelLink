import torch
import numpy as np
from torch_geometric.data import Data
from dataPreprocess import Node_matrix, edge, edge_features
from torch_geometric.nn import GCNConv
import torch.optim as optim
import torch.nn.functional as F
from queue import PriorityQueue

# 数据预处理
Node_matrix = Node_matrix.astype(np.float64)
edge = edge.astype(np.int64)
edge_features = edge_features.astype(np.float64)


# 创建一个Data对象
data = Data(x=torch.tensor(Node_matrix, dtype=torch.float), 
            edge_index=torch.tensor(edge, dtype=torch.long),
            edge_attr=torch.tensor(edge_features, dtype=torch.float))

# 初始data.edge_index是从1开始的，需要减1
data.edge_index = data.edge_index - 1


# 定义GNN`GCN`模型

num_node_features = Node_matrix.shape[1]  # 假设Node_matrix的所有列都是节点特征
output_features = 8  # 假定输出特征的维度为8，根据需要调整

class GCNModel(torch.nn.Module):
    def __init__(self, num_node_features, output_features):
        super(GCNModel, self).__init__()
        self.conv1 = GCNConv(num_node_features, 16)  # 第一个GCN层
        self.conv2 = GCNConv(16, output_features)  # 第二个GCN层，决定输出特征的维度

    def forward(self, x, edge_index):
        x = F.relu(self.conv1(x, edge_index))  # 应用ReLU激活函数
        x = F.dropout(x, training=self.training)  # 应用dropout防止过拟合
        x = self.conv2(x, edge_index)  # 第二层GCN
        return x

# 创建模型和优化器
model = GCNModel(num_node_features=num_node_features, output_features=output_features)
optimizer = optim.Adam(model.parameters(), lr=0.01)
loss_fn = torch.nn.MSELoss()

# 训练模型
model.train()

for epoch in range(200):
    optimizer.zero_grad()
    out = model(data.x, data.edge_index)
    
    # 由于这是一个示例，我们没有真正的目标（labels）来计算损失
    # 在实际应用中，您需要根据任务确定如何计算损失
    # 以下是一个假设的损失计算示例
    loss = loss_fn(out, torch.randn_like(out))  # 假设损失
    loss.backward()
    optimizer.step()
    
    if epoch % 10 == 0:
        print(f'Epoch {epoch}: Loss {loss.item()}')


# After training, we can use the model to make predictions
model.eval()  # 将模型设置为评估模式
with torch.no_grad():
    node_embeddings = model(data.x, data.edge_index) #
# node_embeddings是节点的嵌入表示，可以用于后续任务，如节点分类、链接预测等
    
# print(node_embeddings)



# node_embeddings = torch.tensor(
#       [[-0.0386,  0.1845, -0.0445, -0.3052, -0.1771,  0.0899,  0.0484, -0.2202],
#        [-0.0643,  0.0857, -0.0377, -0.3141, -0.1097,  0.0708, -0.0140, -0.1920],
#        [-0.0907,  0.0997, -0.0412, -0.3563, -0.1388,  0.0681,  0.0097, -0.1903],
#        [-0.1121,  0.2046, -0.0534, -0.4189, -0.2250,  0.0847,  0.0869, -0.2137],
#        [-0.2272, -0.3685, -0.0637, -0.2486, -0.3868,  0.0262,  0.1722, -0.2251],
#        [-0.2302, -0.3657, -0.0642, -0.2537, -0.3911,  0.0260,  0.1758, -0.2252],
#        [-0.2298, -0.3499, -0.0656, -0.2579, -0.4031,  0.0288,  0.1867, -0.2292],
#        [ 0.1995, -0.7451, -0.0096,  0.5195,  0.3173,  0.0102, -0.3719, -0.1420],
#        [ 0.1927, -0.7304, -0.0115,  0.5056,  0.3005,  0.0112, -0.3575, -0.1443],
#        [ 0.1868, -0.7097, -0.0141,  0.4909,  0.2817,  0.0140, -0.3408, -0.1484],
#        [ 0.1800, -0.6951, -0.0160,  0.4770,  0.2650,  0.0150, -0.3264, -0.1507],
#        [-0.2472, -0.3487, -0.0673, -0.2832, -0.4140,  0.0263,  0.1952, -0.2264],
#        [-0.2498, -0.3374, -0.0686, -0.2904, -0.4243,  0.0278,  0.2043, -0.2287],
#        [-0.2529, -0.3288, -0.0697, -0.2972, -0.4336,  0.0286,  0.2124, -0.2303],
#        [ 0.0557,  0.0145, -0.0240, -0.1076,  0.0402,  0.0794, -0.1293, -0.1866],
#        [-0.2586, -0.3232, -0.0708, -0.3071, -0.4413,  0.0286,  0.2189, -0.2306],
#        [0, 0, 0, 0, 0, 0, 0, 0]
#        ])


zero_row = torch.zeros((1, node_embeddings.shape[1])) 
node_embeddings = torch.cat((node_embeddings, zero_row), dim=0)
