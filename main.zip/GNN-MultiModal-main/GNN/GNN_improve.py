import torch
import numpy as np
from torch_geometric.data import Data
from dataPreprocess import Node_matrix, edge, edge_features, data
from torch_geometric.nn import GCNConv
import torch.optim as optim
import torch.nn.functional as F
# import os
# script_dir = os.path.dirname(os.path.abspath(__file__))
# os.chdir(script_dir)



# 初始data.edge_index是从1开始的，需要减1
data.edge_index = data.edge_index - 1

# 定义GNN`GCN`模型
num_node_features = Node_matrix.shape[1]  # 假设Node_matrix的所有列都是节点特征
output_features = 8  # 假定输出特征的维度为8，根据需要调整
class GCNModel(torch.nn.Module):
    def __init__(self, num_node_features, output_features, activation_function=F.relu):
        super(GCNModel, self).__init__()
        self.conv1 = GCNConv(num_node_features, 16)
        self.conv2 = GCNConv(16, output_features)
        self.activation_function = activation_function

    def forward(self, x, edge_index):
        x = self.activation_function(self.conv1(x, edge_index))
        x = F.dropout(x, training=self.training)
        x = self.conv2(x, edge_index)
        return x

def train_gnn(model, data, epochs, optimizer, loss_function):
    model.train()
    for epoch in range(epochs):
        optimizer.zero_grad()
        out = model(data.x, data.edge_index)
        loss = loss_function(out, torch.randn_like(out))  # 假设损失
        loss.backward()
        optimizer.step()
        # if epoch % 10 == 0:
        #     print(f'Epoch {epoch}: Loss {loss.item()}')

def evaluate_gnn(model, data):
    model.eval()
    with torch.no_grad():
        node_embeddings = model(data.x, data.edge_index)
    # node_embeddings最下面加一行0
    zero_row = torch.zeros((1, node_embeddings.shape[1]))
    node_embeddings = torch.cat((node_embeddings, zero_row), dim=0)
    return node_embeddings

