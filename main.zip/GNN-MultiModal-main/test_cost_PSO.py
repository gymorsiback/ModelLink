import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from PSO_cost import *
import pandas as pd
from userRequest import *
from BFS import *
from collections import Counter
from GNN.GNN_init import node_embeddings


if __name__ == "__main__":
    user_id = 1
    request = create_user_requests_by_userID(user_id)
    #设置参数
    # iter,w,s1,s2,population_size
    # 20,0.4,1,1,20
    # 20,0.5,1.2,1,20
    # queue = [[40, 0.9, 2, 1.2, 20]]
    queue = [[40, 0.5, 2, 1.2, 20], [20, 0.4, 1, 1, 20], [10, 0.5, 1.5, 1.2, 10], [30, 0.9, 1.5, 1, 10],
             [50, 0.7, 2, 1.5, 30], [30, 0.6, 1, 1.5, 30], [40, 0.9, 0.8, 1, 10], [20, 1.2, 1.2, 1, 20]]
    n = len(queue)
    # 准备绘图
    fig, ax1 = plt.subplots(figsize=(10, 6))
    colors = ['b', 'g', 'r', 'c', 'm', 'y', 'k']  # 假设有足够多的颜色用于区分不同的组
    line_styles = ['-', '--', '-.', ':']  # 不同的线型，如果需要更多线型可以添加更多
    for i in range(n):
        iters, w, s1, s2, population_size = queue[i]
        '''
        cost, time = PSO(request.Lo, request.La, request.route, float(request.w1), float(request.w2), node_embeddings,
                         iters, w, s1, s2, population_size)
        # print(cost)
        # print(time[0])
        result = {
            "cost": cost,
            "time": time
        }
        df = pd.DataFrame(result)
        df.to_csv(path_or_buf='result/PSO/' + str(iters) + ' ' + str(w) + ' ' + str(s1) + ' ' + str(s2) + ' ' +
                              str(population_size) + ' ' + '.csv', index=False, header=True)
        '''
        name = ('iter = ' + str(iters) + ' ' + 'w = ' + str(w) + ' ' + 's1 = ' + str(s1) + ' ' + 's2 = ' + str(s2) + ' '
                + 'population_size =' + str(population_size))
        path = ('result/PSO/' + str(iters) + ' ' + str(w) + ' ' + str(s1) + ' ' + str(s2) + ' ' +str(population_size) +
                ' ' + '.csv')
        df = pd.read_csv(path)
        cost = df['cost']
        time = df['time']
        ax1.plot(time, cost, color=colors[i % len(colors)],
                 linestyle=line_styles[i % len(line_styles)],
                 label=name)

        # 设置图例
        a1 = ax1.legend()

        # 调整图例字体大小
        for text in a1.get_texts():
            text.set_fontsize('small')  # 或者使用具体的数值，如8
        for line in a1.get_lines():
            line.set_linewidth(1.5)  # 调整线条粗细

    # 设置y轴的标签
    ax1.set_ylabel('Cost', fontsize=15)
    # ax2.set_ylabel(y2)
    ax1.set_xlabel('Time', fontsize=15)
    ax1.grid(True)

    # 设置标题及其字体大小
    ax1.set_title('Cost vs. Time', fontsize=18)

    # 显示图表
    # plt.tight_layout()
    plt.show()




