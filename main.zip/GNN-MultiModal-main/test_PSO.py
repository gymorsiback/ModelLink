import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from PSO_GNN import *
import pandas as pd
from userRequest import *
from BFS import *
from collections import Counter
from GNN.GNN_init import node_embeddings

# 设置参数
# iter-po
# s1-s2
# w

iters = [10, 20, 30, 40, 50]
# ws = [0.4, 0.5, 0.6, 0.7, 0.8, 0.9]      # 惯性权重取值范围一般在0.4~0.9
# s1s = [0.6, 1, 1.2, 1.5, 2]     # 个体学习因子,取值范围通常是在0.5到2
# s2s = [0.6, 0.8, 1, 1.2, 1.5]     # 群体学习因子
population_sizes = [10, 20, 30, 40, 50]

iters = [40]
ws = [0.9]      # 惯性权重取值范围一般在0.4~0.9
s1s = [2]     # 个体学习因子,取值范围通常是在0.5到2
s2s = [1.2]     # 群体学习因子
population_sizes = [20]

# 准确率测试函数
def test_accuracy(user_id, iterr, w, s1, s2, population_size):
    request = create_user_requests_by_userID(user_id)
    path1 = BFS(request.Lo, request.La, request.route, float(request.w1), float(request.w2))
    path2 = PSO(request.Lo, request.La, request.route, float(request.w1), float(request.w2), node_embeddings, iterr, w, s1, s2, population_size)
    return 1 if path1 == path2 else 0


# 鲁棒性测试函数，运行20次取平均
# 在 test_robustness 函数中，修改 results 列表的处理方式
def test_robustness(iterr, w, s1, s2, population_size,user_id=1, repetitions=20):
    request = create_user_requests_by_userID(user_id)
    results = []

    for _ in range(repetitions):
        result = PSO(request.Lo, request.La, request.route, float(request.w1), float(request.w2), node_embeddings,iterr, w, s1, s2, population_size)
        results.append(result)

    # 将列表中的列表转换为元组，使其可哈希
    hashable_results = [tuple(r) if isinstance(r, list) else r for r in results]

    # 然后计算最常见结果的频率
    most_common_result, count = Counter(hashable_results).most_common(1)[0]
    return count / repetitions

# 主测试函数
def main():
    user_ids = range(1, 101)
    robustness_rates = 0
    accuracy_rate = 0
    accuracy_counts = 0
    results = []

    for iterr in iters:
        for w in ws:
            for s1 in s1s:
                for s2 in s2s:
                    for population_size in population_sizes:
                        accuracy_counts = 0
                        for user_id in user_ids:
                            request = create_user_requests_by_userID(user_id)
                            # 准确率测试
                            accuracy_counts += test_accuracy(user_id, iterr, w, s1, s2, population_size)

                            # 仅对 user_id 为 1 的情况测试鲁棒性
                            if user_id == 1:
                                robustness_rates = test_robustness(iterr, w, s1, s2, population_size)
                        accuracy_rate = accuracy_counts / len(user_ids)
                        # 存入csv
                        result = {
                            'iter': iterr,
                            'w': w,
                            's1': s1,
                            's2': s2,
                            'population_size': population_size,
                            'accuracy_rate': accuracy_rate,
                            'robustness_rates': robustness_rates
                        }
                        results.append(result)

    df = pd.DataFrame(results)
    # 第一次跑的时候header为true，之后为false
    df.to_csv('result/PSO/pso_ws_results.csv', index=False, header=True)

# 运行主测试函数
if __name__ == "__main__":
    main()


    # 读取CSV文件
    df = pd.read_csv('result/PSO/pso_ws_results.csv')
    # 选准确率最大值：
    column_name = 'accuracy_rate'
    # 找到该列的最大值
    max_value = df[column_name].max()
    # 筛选出该列值为最大值的行
    max_value_rows = df[df[column_name] == max_value]
    # 显示筛选出的行
    print('accuracy_rate max')
    print(max_value_rows)

    # 选鲁棒性最大值：
    column_name = 'robustness_rates'
    max_value = df[column_name].max()
    max_value_rows = df[df[column_name] == max_value]
    print('robustness_rates max')
    print(max_value_rows)
