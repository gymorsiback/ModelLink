import pandas as pd

# 读取 CSV 文件到 pandas 数据帧
df_server = pd.read_csv('Server_data.csv')
df_models = pd.read_csv('models.csv')

# 通过 ModelID 合并两个数据帧
df_merged = pd.merge(df_server, df_models, on='ModelID')
df_merged.to_csv('merged.csv', index=False)



# # 根据 ServerID 分组，并将 ModelPerformance 和 ModelEfficiency 放入列表
# 根据 ServerID 分组，并将 ModelID 和对应的 ModelPerformance 和 ModelEfficiency 放入字典
result = df_merged.groupby('ServerID_x').apply(lambda x: x.set_index('ModelID')[['ModelPerformance', 'ModelEfficiency']].T.to_dict()).to_dict()
print(result)
# 将字典转换为 DataFrame
df_new = pd.DataFrame.from_dict(result, orient='index')
df_new.to_csv('new_merged.csv', index_label='ServerID')

# 删除server中的ModelID列
df_server = df_server.drop(columns='ModelID')
# 去重
df_new_server = df_server.drop_duplicates(subset='ServerID', keep='first', inplace=False)
print(df_new_server)

# 将 new_merged 的每一行转换为字典，并添加为 server 的新属性
for index, row in df_new.iterrows():
    # 删除空值
    row = row.dropna()
    # 将 Series 转换为字典
    row_dict = row.to_dict()
    # print(row_dict)
    # in_dict = row_dict.get(index)
    
    # 
    for k, v in row_dict.items():
        # print(v)
        new_list = []
        for key, value in v.items():
            # print(value)
            new_list.append(value)
        row_dict[k] = new_list
    
    # print(df_new_server[df_new_server['ServerID'] == index])
    # 将字典添加为 server 的新属性
    df_new_server.loc[df_new_server['ServerID'] == index, 'Models'] = [row_dict]

print(df_new_server)

# 将新的 server 数据保存到 CSV 文件
df_new_server.to_csv('new_server_data.csv', index=False)
    
    
