import pandas as pd

# 假设文件路径已正确设置，下面是读取和合并这些文件的代码

# 读取CSV文件
model_a2t = pd.read_csv('model_a2t.csv')
model_i2v = pd.read_csv('model_i2v.csv')
model_t2a = pd.read_csv('model_t2a.csv')
model_t2t = pd.read_csv('model_t2t.csv')
model_t2v = pd.read_csv('model_t2v.csv')
model_t2i = pd.read_csv('model_t2i.csv')

# 合并这些DataFrame
all_models = pd.concat([model_a2t, model_i2v, model_t2a, model_t2t, model_t2v, model_t2i])

# 按 ModelID 排序
all_models_sorted = all_models.sort_values('ModelID')

# 查看合并后的数据
print(all_models_sorted.head())

# 如果需要将合并后的数据保存到新的CSV文件
all_models_sorted.to_csv('merged_models.csv', index=False)
