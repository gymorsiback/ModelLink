import pandas as pd
import random

# 读取data/edge-servers/site.csv
site = pd.read_csv('edge-servers/site_test.csv')
# 提取经纬度
coordinates = site[['LATITUDE', 'LONGITUDE']]
print(coordinates)
# 读取server_data.csv
server_data = pd.read_csv('server_data.csv')

# 获取当前server_data中的最大ModelID和ServerID
max_model_id = server_data['ModelID'].max()
max_server_id = server_data['ServerID'].max()

# 生成新的数据行
new_rows = []
for i in range(len(coordinates)):
    print(f"-------{i}th coordinates-------")
    # 获取经纬度
    latitude = coordinates.loc[i, 'LATITUDE']
    longitude = coordinates.loc[i, 'LONGITUDE']
    
    repeatTime = random.randint(1, 5)
    # 重复使用经纬度
    new_rows_for_model = []
    for j in range(1, repeatTime + 1):
        # 生成新的行数据
        max_model_id += 1
        new_row = {
            'ModelID': max_model_id ,
            'ServerID': max_server_id + 1,
            'Longitude': longitude,
            'Latitude': latitude,
            'ServerPerformance': random.uniform(1, 2)
        }
        new_rows.append(new_row)
        # 更新model_x2y.csv文件   
        # 随机选择一个1~6的值
        typeId = random.randint(1, 6)
        type = {
            1: 't2t',
            2: 't2i',
            3: 'i2v',
            4: 't2v',
            5: 'a2t',
            6: 't2a'
        }
        # 构造文件名
        file_name = f'model_{type[typeId]}.csv'
        # 读取文件内容
        model_data = pd.read_csv(file_name)
        # 生成新的行数据
        new_row_for_model = {
            'ModelID': max_model_id,
            'ServerID': max_server_id + 1,
            'ModelEfficiency': random.uniform(0, 1),
            'ModelPerformance': random.uniform(1, 2)
        }
        # 将新的行添加到model_data中
        new_rows_for_model.append(new_row_for_model)
        
    new_model_data = pd.DataFrame(new_rows_for_model)
    model_data = pd.concat([model_data, new_model_data], ignore_index=True)
    # 保存更新后的model_data
    model_data.to_csv(file_name, index=False)

    max_server_id += 1

    

# 将新的数据行添加到server_data中
new_data = pd.DataFrame(new_rows)
server_data = pd.concat([server_data, new_data], ignore_index=True)

# 保存更新后的server_data
server_data.to_csv('server_data.csv', index=False)
