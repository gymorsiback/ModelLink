from dataPreprocess import *
from collections import defaultdict
from GNN import *
import numpy as np
import heapq


def Greedy(lo, la, route, w1, w2, node_embeddings,edge=edge,edge_features=edge_features,locations=locations,model_performence=model_performence):
    # 将列表解析成经度和纬度的两个列表
    import copy
    edge_copy = copy.deepcopy(edge)
    edge_features_copy = copy.deepcopy(edge_features)
    locations_copy = copy.deepcopy(locations)
    model_performence_copy = copy.deepcopy(model_performence)

    longitude, latitude = zip(*locations_copy)
    route.insert(0, len(locations_copy) + 1)
    route.append(len(locations_copy) + 1)
    # 计算[lo,la]到locations中所有坐标的距离
    distance = [haversine(lo, la, lon, lat) for lon, lat in zip(longitude, latitude)]
    edge_copy = edge_copy.tolist()
    edge_features_copy = edge_features_copy.tolist()

    # 将[lo,la]到所有其他节点的边添加到 edge 中
    for i in range(len(locations_copy)):
        # 可去
        edge_copy[0].append(len(locations_copy) + 1)  # 17 号点的索引
        edge_copy[1].append(i + 1)
        # 可回
        edge_copy[0].append(i + 1)
        edge_copy[1].append(len(locations_copy) + 1)
    # 复制每个元素并放在原元素的后面
    distance_copy = np.repeat(distance, 2)

    # 将相应的距离添加到 edge_features 中
    edge_features_flat = [item for sublist in edge_features_copy for item in sublist]
    edge_features_flat.extend(distance_copy)  # 可以把每条边target点上耽误的时间都算进这条边的距离中，具体计算为这条边对应target点的(c1/server_performence + c2/model_efficiency)加到对应的edge_features_flat中
    node_efficiency = []

    # 权重，根据测试自己调整
    c1 = 1
    c2 = 0.1
    c3 = 1
    # model_performence
    for i in range(len(model_efficiency)):
        node_efficiency.append(c1 / (server_performence[i] * model_efficiency[i]))  # (c1 / server_performence[i]) + (c2 / model_efficiency[i])
    node_efficiency = [float(value) for value in node_efficiency]
    second_elements = [sub_array[1] for sub_array in model_performence_copy]  # second_elements是model_performence中元素的第二个元素
    for i in range(len(edge_copy[1])):
        if edge_copy[1][i] == len(locations_copy) + 1:
            edge_features_flat[i] += 0
        else:
            edge_features_flat[i] = w1 * (node_efficiency[edge_copy[1][i] - 1] + c2 * edge_features_flat[i]) + w2 * (c3 / second_elements[edge_copy[1][i] - 1])
    # print("edge =", edge)
    # print("edge_features_flat =", edge_features_flat)
    Y_copy = copy.deepcopy(Y)
    Y_copy.append(len(locations_copy) + 1)
    # print(Y_copy)
    # Initialize the route_pro array
    route_pro = []
    # Fill route_pro based on the condition
    for r in route:
        indices = [i + 1 for i, y in enumerate(Y_copy) if y == r]
        route_pro.append(indices)
    # print(route_pro)

    from collections import deque

    def construct_graph(edge, edge_features_flat):
        graph = {}
        for start, end, cost in zip(edge[0], edge[1], edge_features_flat):
            if start not in graph:
                graph[start] = {}
            graph[start][end] = cost
        # print("graph =",graph)
        return graph

    def find_optimal_path_greedy(graph, route_pro):
        if not route_pro:
            return [], 0

        total_cost = 0
        path = [route_pro[0][0]]  # 开始于route_pro的第一个节点集的第一个元素

        for i in range(len(route_pro) - 1):
            # current_group = route_pro[i]
            next_group = route_pro[i + 1]
            min_cost = float('inf')
            chosen_node = None
            current_node = path[-1]  # 开始于当前路径的最后一个节点

            for next_node in next_group:
                if current_node in graph and next_node in graph[current_node]:
                    cost = graph[current_node][next_node]
                    if cost < min_cost:
                        min_cost = cost
                        chosen_node = next_node

            if chosen_node is not None:
                path.append(chosen_node)
                total_cost += min_cost
            else:
                # 如果没有找到合适的下一个节点，则返回当前路径和代价
                return path, total_cost

        return path, total_cost

    def find_optimal_path(edge, edge_features_flat, route_pro):
        graph = construct_graph(edge, edge_features_flat)
        optimal_path, cost = find_optimal_path_greedy(graph, route_pro)
        return optimal_path, cost

    path, cost = find_optimal_path(edge_copy, edge_features_flat, route_pro)
    # print(f"Greedy Path: {path}, Cost: {cost}")
    route.pop(0)
    route.pop()
    return path


